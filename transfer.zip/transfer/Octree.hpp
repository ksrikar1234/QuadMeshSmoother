#ifndef _GP_UNSTRUCTURED_OCTREE_HPP_
#define _GP_UNSTRUCTURED_OCTREE_HPP_

#include <array>
#include <vector>
#include <deque>

#include <memory>
#include <atomic>
#include <mutex>
#include <thread>
#include <condition_variable>

#include <algorithm>

#include "GridTraits.hpp"

#include "../../common_headers/common/coord.hpp"


namespace Unstructured
{
    class BoundingBox;
    class OctreeNode;
/*
    * Octree class
    * This class is used to create an octree data structure for spatial partitioning of any geometry that has base class Generic::Element
    * Useful for Spatial queries and Intersection tests
    * Its Implemnted using a recursive structure of OctreeNodes
    * Generic::Element is the base class for the elements that are stored in the Octree leaf nodes
    * The Octree is created with a bounding box that represents the root node
    * Depth of the tree is can be controlled by the number of elements that can be stored in a node
    * Has the Following functions:
    * 1. add_element(Generic::Element* element) : Adds an element to the octree
    * 2. get_elements() : Returns all the elements in the octree
    * 3. get_intersecting_elements(const double& a, const double& b, const double& c, const double& d) : Returns all the elements that intersect with the plane ax + by + cz + d = 0
    * 4. get_elements_on_side_of_plane(const double& a, const double& b, const double& c, const double& d, const bool& is_positive_side) : Returns all the elements on the side of the plane ax + by + cz + d = 0
    * 5. get_all_nodes_bounding_boxes() : Returns the bounding boxes of all the nodes in the octree
    * 6. get_all_child_nodes() : Returns all the child nodes of the octree 
*/
    class Octree;
}


namespace gp_std
{
    template <typename T, typename... Args>
    inline std::unique_ptr<T> make_unique(Args&&... args)
    {
        return std::unique_ptr<T>(new T(std::forward<Args>(args)...));
    }
}

namespace Unstructured 
{
    class spinlock
    {
    public:
        spinlock() : lock_status(false) {}
        spinlock(const bool &initial_state)
        {
            if (initial_state)
                lock();
            else
                unlock();
        }

        ~spinlock() { unlock(); }

        void lock()
        {
            while (lock_status.exchange(true))
            {
            }
        }
        
        void force_acquire()
        {
            lock_status.store(true);
        }

        bool try_lock()
        {
            return !lock_status.exchange(true);
        }

        void unlock()
        {
            lock_status.store(false);
        }

        bool is_locked()
        {
            return lock_status.load();
        }

        bool is_lock_free()
        {
            return lock_status.is_lock_free();
        }

    private:
        std::atomic<bool> lock_status;
    };

class BoundingBox
{
public:
   explicit BoundingBox(const coord& min, const coord& max) : min(min), max(max) {}
   
   BoundingBox(const BoundingBox& in) : min(in.min), max(in.max) {}
   BoundingBox(BoundingBox&& in) : min(in.min), max(in.max) {}

   BoundingBox& operator=(const BoundingBox& in)
   {
      min = in.min; max = in.max;
      return *this;
   }

  ~BoundingBox() {}

    BoundingBox get_quadrant(const int& index) const
    {
        // Calculate the midpoint for each axis
        coord mid = (max + min) / 2.0;

        // Subdivide into 8 quadrants based on the index
        switch (index)
        {
            // Lower-left-front quadrant
            case 0: return BoundingBox({ min.x, min.y, min.z }, { mid.x, mid.y, mid.z });

            // Lower-right-front quadrant
            case 1: return BoundingBox({ mid.x, min.y, min.z }, { max.x, mid.y, mid.z });

            // Upper-left-front quadrant
            case 2: return BoundingBox({ min.x, mid.y, min.z }, { mid.x, max.y, mid.z });

            // Upper-right-front quadrant
            case 3: return BoundingBox({ mid.x, mid.y, min.z }, { max.x, max.y, mid.z });

            // Lower-left-back quadrant
            case 4: return BoundingBox({ min.x, min.y, mid.z }, { mid.x, mid.y, max.z });

            // Lower-right-back quadrant
            case 5: return BoundingBox({ mid.x, min.y, mid.z }, { max.x, mid.y, max.z });

            // Upper-left-back quadrant
            case 6: return BoundingBox({ min.x, mid.y, mid.z }, { mid.x, max.y, max.z });

            // Upper-right-back quadrant
            case 7: return BoundingBox(mid, max);

            // Default (should never reach here)
            default: return BoundingBox(min, max);
        }
    }

    bool contains(const coord& point) const
    {
        return (point.x >= min.x && point.x <= max.x &&
                point.y >= min.y && point.y <= max.y &&
                point.z >= min.z && point.z <= max.z);
    }

    std::array<coord , 8> get_nodes() const
    {
       std::array<coord, 8> nodes 
       {
          { {min.x, min.y, min.z}, {max.x, min.y, min.z}, {min.x, max.y, min.z}, {max.x, max.y, min.z},
            {min.x, min.y, max.z}, {max.x, min.y, max.z}, {min.x, max.y, max.z}, {max.x, max.y, max.z} }
       };
       return nodes;

    }

    bool is_intersecting_plane(const double& a, const double& b, const double& c, const double& d) const
    {
        // Check if all nodes are on the same side of the plane
        std::array<coord, 8> nodes = get_nodes();
        int num_nodes = 0;
        for (auto& node : nodes)
        {
            double val = a * node.x + b * node.y + c * node.z + d;
            if (val > 0)
                ++num_nodes;
        }
        return num_nodes != 0 && num_nodes != 8;
    }

    bool is_positive_side(const double& a, const double& b, const double& c, const double& d) const
    {
        // Check if all nodes are on the same side of the plane
        std::array<coord, 8> nodes = get_nodes();
        int num_nodes = 0;
        for (auto& node : nodes)
        {
            double val = a * node.x + b * node.y + c * node.z + d;
            if (val > 0)
                ++num_nodes;
        }
        return (num_nodes == 8);      
    }

    std::vector<uint32_t> get_bounding_box_lines() const
    {
        std::vector<uint32_t> lines = { 0, 1, 1, 3, 3, 2, 2, 0, 4, 5, 5, 7, 7, 6, 6, 4, 0, 4, 1, 5, 3, 7, 2, 6 };
        return lines;
    }
    
    std::vector<float> get_vertices() const
    {
        std::vector<float> vertices(8*3);
        std::array<coord, 8> nodes = get_nodes();

        uint32_t i = 0;
        for (auto& node : nodes)
        {
            vertices[i]   = node.x;
            vertices[i+1] = node.y;
            vertices[i+2] = node.z;
            i += 3;
        }
        return vertices;
    }

    coord min, max;
};

class OctreeNode
{
public:
    explicit OctreeNode(const coord& min, const coord& max, uint32_t expected_max_num_elements) 
    :  MAX_NUMBER_OF_ELEMENTS_PER_NODE(expected_max_num_elements), subdivision_status(false), curr_num_elements(0), m_boundingBox(min, max) , m_children({nullptr}) , m_elements(expected_max_num_elements) {}
    
    OctreeNode(const OctreeNode& in) : MAX_NUMBER_OF_ELEMENTS_PER_NODE(in.MAX_NUMBER_OF_ELEMENTS_PER_NODE), subdivision_status(in.subdivision_status.load()), curr_num_elements(in.curr_num_elements.load()), m_boundingBox(in.m_boundingBox), m_elements(in.m_elements)
    {
        for (int i = 0; i < 8; i++)
        {
            m_children[i] = gp_std::make_unique<OctreeNode>(*in.m_children[i]);
        }
    }

    OctreeNode(OctreeNode&& in) : MAX_NUMBER_OF_ELEMENTS_PER_NODE(in.MAX_NUMBER_OF_ELEMENTS_PER_NODE), subdivision_status(in.subdivision_status.load()), curr_num_elements(in.curr_num_elements.load()), m_boundingBox(in.m_boundingBox), m_elements(std::move(in.m_elements))
    {
        for (int i = 0; i < 8; i++)
        {
            m_children[i] = std::move(in.m_children[i]);
        }
    }

    OctreeNode& operator=(const OctreeNode& in)
    {
        subdivision_status.store(in.subdivision_status.load());
        m_boundingBox = in.m_boundingBox;
        m_elements = in.m_elements;
        curr_num_elements.store(in.curr_num_elements.load());
        
        for (int i = 0; i < 8; i++)
        {
            m_children[i] = gp_std::make_unique<OctreeNode>(*in.m_children[i]);
        }

        subdivision_status.store(in.subdivision_status.load());

        return *this;
    }

    OctreeNode& operator=(OctreeNode&& in)
    {
        subdivision_status.store(in.subdivision_status.load());
        m_boundingBox = in.m_boundingBox;
        m_elements = std::move(in.m_elements);
        curr_num_elements.store(in.curr_num_elements.load());
    
        for (int i = 0; i < 8; i++)
        {
            m_children[i] = std::move(in.m_children[i]);
        }
        return *this;
    }

   ~OctreeNode() {}


   bool is_intersecting_plane(const double& a, const double& b, const double& c, const double& d) const
   {
      if(get_num_elements() == 0)
      {
          return false;
      }
      return m_boundingBox.is_intersecting_plane(a, b, c, d);
   }

    bool add_element(Generic::Element*& element)
    {   
        bool is_within = false;
        for(auto& coord : element->get_coords())
        {
            // Check if at least one of the coordinates is within the bounding box
            if(m_boundingBox.contains(*coord))
            {
                is_within = true;
                break;
            }  
        }

        if(!is_within)
            return false;

        if (!is_subdivided())
        {
            if (get_num_elements() >= MAX_NUMBER_OF_ELEMENTS_PER_NODE)
            {
                if (subdivision_process_lock.try_lock())
                {
                    subdivide();
                }

                while (subdivision_process_lock.is_locked())
                {
                }
            }
            else
            {
                m_elements[curr_num_elements.fetch_add(1) - 1] = element;
            }
        }
        else
        {
            for (int i = 0; i < 8; i++)
            {
                if (m_children[i]->add_element(element))
                    return true;
            }
        }

        return true;
    }

   std::vector<Generic::Element*> get_elements() const
   {
        if(is_subdivided())
        {
            std::vector<Generic::Element*> elements;
            for (int i = 0; i < 8; i++)
            {
                std::vector<Generic::Element*> child_elements = m_children[i]->get_elements();
                elements.insert(elements.end(), child_elements.begin(), child_elements.end());
            }
            return elements;
        }
        return m_elements;
   }

   std::vector<const OctreeNode*> get_intersecting_nodes(const double& a, const double& b, const double& c, const double& d)  const
   {
       std::vector<const OctreeNode*> nodes;
       if(is_intersecting_plane(a, b, c, d))
       {
           if(is_subdivided())
           {
               for (int i = 0; i < 8; ++i)
               {
                   std::vector<const OctreeNode*> child_nodes = m_children[i]->get_intersecting_nodes(a, b, c, d);
                   nodes.insert(nodes.end(), child_nodes.begin(), child_nodes.end());
               }
           }
           else
           {
               nodes.emplace_back(this);
           }
       }
       return nodes;
   }
    
   std::vector<const OctreeNode*> get_nodes_on_side_of_plane(const double& a, const double& b, const double& c, const double& d, const bool& is_postive_side) const
   {
         std::vector<const OctreeNode*> nodes;
         if(is_subdivided())
         {
             for (int i = 0; i < 8; i++)
             {
                 std::vector<const OctreeNode*> child_nodes = m_children[i]->get_nodes_on_side_of_plane(a, b, c, d, is_postive_side);
                 nodes.insert(nodes.end(), child_nodes.begin(), child_nodes.end());
             }
         }
         else
         {
             if(m_boundingBox.is_positive_side(a, b, c, d) == is_postive_side)
             {
                 nodes.emplace_back(this);
             }
         }

         return nodes;
   }
   
   BoundingBox get_bounding_box() const
   {
       return m_boundingBox;
   }

   std::vector<BoundingBox> get_all_child_bounding_boxes() const
   {
        std::vector<BoundingBox> bounding_boxes;
        if(is_subdivided())
        {
           for(int i = 0; i < 8; ++i)
           {
               std::vector<BoundingBox> child_bounding_box = m_children[i]->get_all_child_bounding_boxes();
               bounding_boxes.insert(bounding_boxes.end(), child_bounding_box.begin(), child_bounding_box.end());
           }
        }
        else
        {
            bounding_boxes.push_back(m_boundingBox);
        }
        return bounding_boxes;
   }

   std::vector<OctreeNode*> get_all_child_nodes()
   {
        std::vector<OctreeNode*> nodes;
        if(is_subdivided())
        {
            for (int i = 0; i < 8; i++)
            {
              std::vector<OctreeNode*> child_nodes = m_children[i]->get_all_child_nodes();
              nodes.insert(nodes.end(), child_nodes.begin(), child_nodes.end());
            }
        }
        else
        {
            nodes.emplace_back(this);
        }
        return nodes;
   }

   private:
   void subdivide()
   {
        subdivision_process_lock.force_acquire();

        // Create 8 children
        for (int i = 0; i < 8; ++i)
        {
            auto sub_bb = m_boundingBox.get_quadrant(i);
            m_children[i] = gp_std::make_unique<OctreeNode>(sub_bb.min, sub_bb.max, MAX_NUMBER_OF_ELEMENTS_PER_NODE);
        }

        for(auto element : m_elements)
        {
            //try to add the elements to all the children nodes and one of them will accept it
            for (int i = 0; i < 8; ++i)
            {
                if(m_children[i]->add_element(element))
                break;
            }
        }
        m_elements.clear();
        subdivision_status.store(true);    
        subdivision_process_lock.unlock();    
   }   

   bool is_leaf_node() const
   {
       return !(subdivision_status);
   }

   bool is_subdivided() const
   {
       return subdivision_status.load();
   }

   uint32_t get_num_elements() const
   {
       return curr_num_elements.load();
   }
   
   private:
   uint32_t MAX_NUMBER_OF_ELEMENTS_PER_NODE;
   std::atomic<bool>     subdivision_status;
   std::atomic<uint32_t> curr_num_elements;
   spinlock              subdivision_process_lock;
   BoundingBox           m_boundingBox;
   std::array<std::unique_ptr<OctreeNode>, 8> m_children;
   std::vector<Generic::Element*> m_elements;
};


class Octree
{

public:
    explicit Octree(const coord& min, const coord& max, uint32_t expected_max_num_elements = 64) : m_root(min, max, expected_max_num_elements) {}
   ~Octree() {}

    void add_element(Generic::Element* element)
    {
        m_root.add_element(element);
    }

    void add_elements_parallel(const std::vector<Generic::Element *> &elements, uint32_t num_threads, uint32_t batches = 128)
    {
        size_t num_elements = elements.size();
        struct chunk
        {
            size_t start;
            size_t end;
        };

        size_t chunk_size = num_elements / batches;
        std::vector<chunk> chunks(batches);

        for (size_t i = 0; i < batches; ++i)
        {
            chunks[i].start = i * chunk_size;
            chunks[i].end = (i == batches - 1) ? num_elements : (i + 1) * chunk_size;
        }

        auto worker = [this, &elements](const chunk &c)
        {
            for (size_t i = c.start; i < c.end; ++i)
            {
                add_element(elements[i]);
            }
        };

        std::mutex m;
        std::condition_variable cv;
        std::deque<chunk> work_queue(chunks.begin(), chunks.end());
        std::atomic<uint32_t> counter(0);
        std::atomic<bool> done(false);

        auto worker_loop = [&m, &cv, &work_queue, &counter, &done, &worker]()
        {
            while (true)
            {
                chunk c;
                {
                    std::unique_lock<std::mutex> lock(m);
                    cv.wait(lock, [&]()
                            { return !work_queue.empty() || done; });

                    if (done && work_queue.empty())
                        return; // Exit condition

                    c = work_queue.back();
                    work_queue.pop_back();
                }

                worker(c);
                counter.fetch_add(1);
            }
        };

        // Create worker threads
        std::vector<std::thread> threads;
        for (size_t i = 0; i < num_threads; ++i)
        {
            threads.emplace_back(worker_loop);
        }

        // Wait for all tasks to be done
        while (counter.load() < batches)
        {
            cv.notify_all();
            std::this_thread::yield();
        }

        // Signal threads to exit
        done = true;
        cv.notify_all();

        // Join all threads
        for (auto &t : threads)
        {
            t.join();
        }
    }

    std::vector<Generic::Element*> get_elements() 
    {
        return m_root.get_elements();
    }

    std::vector<Generic::Element*> get_intersecting_elements(const double& a, const double& b, const double& c, const double& d) 
    {
        std::vector<Generic::Element*> elements;
        std::vector<const OctreeNode*> nodes = m_root.get_intersecting_nodes(a, b, c, d);
        for(auto& node : nodes)
        {
            std::vector<Generic::Element*> node_elements = node->get_elements();
            for(auto& elem : node_elements)
            {
                int val = 0;
                auto coords = elem->get_coords();
                for(auto& C : coords)
                {
                    if(a*(C->x) +  b*(C->y) + c*(C->z) + d > 0)  { ++val; }
                }
                if(val != 0 && static_cast<unsigned int>(val) != coords.size()) { elements.emplace_back(elem); }
            }
        }
        return elements;
    }

    std::vector<Generic::Element*> get_elements_on_side_of_plane(const double& a, const double& b, const double& c, const double& d, const bool& is_positive_side)
    {
        std::vector<Generic::Element*> elements;
        std::vector<const OctreeNode*> intersecting_nodes = m_root.get_intersecting_nodes(a, b, c, d); 
        std::vector<const OctreeNode*> nodes_on_side = m_root.get_nodes_on_side_of_plane(a, b, c, d , is_positive_side); 

        for(auto& node : nodes_on_side)
        {
            std::vector<Generic::Element*> node_elements = node->get_elements();
            elements.insert(elements.end(), node_elements.begin(), node_elements.end());
        }

        for(auto& node : intersecting_nodes)
        {
            auto tmp_elements = node->get_elements();
            for(auto& elem :  tmp_elements)
            {
                auto coords = elem->get_coords();
                bool valid = true;
                for(auto& C :  coords)
                {
                    if(is_positive_side)
                    {
                      if(a*(C->x) +  b*(C->y) + c*(C->z) + d > 0)  {}
                      else { valid = false; break; } 
                    }
                    else
                    {
                      if(a*(C->x) +  b*(C->y) + c*(C->z) + d < 0)  {}
                      else { valid = false; break; }
                    }
                }

                if(valid)
                elements.emplace_back(elem);
            }
        }
        return elements;
    }

    std::vector<BoundingBox> get_all_nodes_bounding_boxes()
    {
       auto bb_list =  m_root.get_all_child_bounding_boxes();
       bb_list.push_back(m_root.get_bounding_box());
       return bb_list;
    }

    std::vector<OctreeNode*> get_all_child_nodes()
    {
        return m_root.get_all_child_nodes();
    }

private:
    OctreeNode m_root;
};

} // namespace Unstructured


#endif // _GP_UNSTRUCTED_OCTREE_HPP