#include "grid_headers/unstructured/UnstructuredGrid.hpp"
#include "grid_headers/unstructured/IR_UnstructuredGrid.hpp"

UnstructuredGrid::UnstructuredGrid(const char* name) : Generic::Domain(Generic::Domain::Unstructured) , m_grid_id(get_unique_grid_id()) 
{
     m_grid_name = name; 
}


UnstructuredGrid::UnstructuredGrid(const UnstructuredGrid& in)  : Domain(in), m_grid_id(in.get_unique_grid_id()), m_grid_name(in.m_grid_name), m_elements(in.m_elements), 
  m_nodes(in.m_nodes), m_edges(in.m_edges), m_triangles(in.m_triangles), m_quads(in.m_quads),
  m_tetrahedrons(in.m_tetrahedrons), m_pyramids(in.m_pyramids), m_hexahedrons(in.m_hexahedrons),
  m_node_id_map(in.m_node_id_map), m_edge_id_map(in.m_edge_id_map), m_triangle_id_map(in.m_triangle_id_map),
  m_quad_id_map(in.m_quad_id_map), m_tetrahedron_id_map(in.m_tetrahedron_id_map), 
  m_pyramid_id_map(in.m_pyramid_id_map), m_hexahedron_id_map(in.m_hexahedron_id_map)                                              
{

}
    
UnstructuredGrid::UnstructuredGrid(UnstructuredGrid&& in)  : Domain(in), m_grid_id(in.m_grid_id), m_grid_name(std::move(in.m_grid_name)), m_elements(std::move(in.m_elements)),
    m_nodes(std::move(in.m_nodes)), m_edges(std::move(in.m_edges)), m_triangles(std::move(in.m_triangles)), 
    m_quads(std::move(in.m_quads)), m_tetrahedrons(std::move(in.m_tetrahedrons)),
    m_pyramids(std::move(in.m_pyramids)), m_hexahedrons(std::move(in.m_hexahedrons)),
    m_node_id_map(std::move(in.m_node_id_map)), m_edge_id_map(std::move(in.m_edge_id_map)), 
    m_triangle_id_map(std::move(in.m_triangle_id_map)), m_quad_id_map(std::move(in.m_quad_id_map)), 
    m_tetrahedron_id_map(std::move(in.m_tetrahedron_id_map)), m_pyramid_id_map(std::move(in.m_pyramid_id_map)), 
    m_hexahedron_id_map(std::move(in.m_hexahedron_id_map))
{

} 

void UnstructuredGrid::load_gmsh(const char* filename)
{
    printf("Loading Gmsh Grid\n");
    // Load Gmsh Grid
    IR_UnstructuredGrid ir_grid;
    ir_grid.load_gmsh(filename);
    load_ir_grid(ir_grid);
    printf("Gmsh Grid Loaded\n");
}


void UnstructuredGrid::load_ir_grid(const IR_UnstructuredGrid& in)
{
    printf("Loading IR Grid\n");
    const std::vector<coord>& coords = in.get_coords();
    printf("Coords size : %d\n", coords.size());
    
    // // for(auto& coord : coords)
    // // { add_node(coord); }

    // printf("Nodes Added\n");
    // printf("Nodes size : %d\n", m_nodes.size());
    
    // const std::vector<IR_UnstructuredGrid::Edge>& edges = in.get_edges();

    // for(auto& edge : edges)
    // {
    //     auto node1 = add_node(coords[edge.node_1]);
    //     auto node2 = add_node(coords[edge.node_2]);
    //     add_edge(node1, node2);
    // }

    // const std::vector<IR_UnstructuredGrid::Triangle>& triangles = in.get_triangles();

    // for(auto& triangle : triangles)
    // {
    //    auto node1 = add_node(coords[triangle.node_1]);
    //    auto node2 = add_node(coords[triangle.node_2]);
    //    auto node3 = add_node(coords[triangle.node_3]);  
       
    //    auto edge1 = add_edge(node1, node2);
    //    auto edge2 = add_edge(node2, node3);
    //    auto edge3 = add_edge(node3, node1);

    //    add_triangle(edge1, edge2, edge3);
    // }

    // const std::vector<IR_UnstructuredGrid::Quad>& quads = in.get_quads();

    // for(auto& quad : quads)
    // {
    //    auto node1 = add_node(coords[quad.node_1]);
    //    auto node2 = add_node(coords[quad.node_2]);
    //    auto node3 = add_node(coords[quad.node_3]);
    //    auto node4 = add_node(coords[quad.node_4]);

    //    auto edge1 = add_edge(node1, node2);
    //    auto edge2 = add_edge(node2, node3);
    //    auto edge3 = add_edge(node3, node4);
    //    auto edge4 = add_edge(node4, node1);

    //    add_quad(edge1, edge2, edge3, edge4);
    // }

    const std::vector<IR_UnstructuredGrid::Tetrahedron>& tetrahedrons = in.get_tetrahedrons();

    for(auto& tetrahedron : tetrahedrons)
    {
       NodeIter node1 = add_node(coords[tetrahedron.node_1]);
       NodeIter node2 = add_node(coords[tetrahedron.node_2]);
       NodeIter node3 = add_node(coords[tetrahedron.node_3]);
       NodeIter node4 = add_node(coords[tetrahedron.node_4]);
       
       EdgeIter edge1 = add_edge(node1, node2);
       EdgeIter edge2 = add_edge(node1, node3);
       EdgeIter edge3 = add_edge(node1, node4);
       EdgeIter edge4 = add_edge(node2, node3);
       EdgeIter edge5 = add_edge(node2, node4);
       EdgeIter edge6 = add_edge(node3, node4);

       TriangleIter tria1 = add_triangle(edge1, edge2, edge3);
       TriangleIter tria2 = add_triangle(edge1, edge4, edge5);
       TriangleIter tria3 = add_triangle(edge2, edge4, edge6);
       TriangleIter tria4 = add_triangle(edge3, edge5, edge6);

       add_tetrahedron(tria1, tria2, tria3, tria4);
    }

    printf("IR Grid Loaded\n");
}

UnstructuredGrid& UnstructuredGrid::operator=(const UnstructuredGrid& in) 
{
    m_elements = in.m_elements; m_edges = in.m_edges; m_triangles = in.m_triangles; 
    m_quads = in.m_quads; m_tetrahedrons = in.m_tetrahedrons; m_pyramids = in.m_pyramids;
    m_hexahedrons = in.m_hexahedrons; 
    m_node_id_map = in.m_node_id_map; m_edge_id_map = in.m_edge_id_map; 
    m_triangle_id_map = in.m_triangle_id_map; m_quad_id_map = in.m_quad_id_map; 
    m_tetrahedron_id_map = in.m_tetrahedron_id_map; m_pyramid_id_map = in.m_pyramid_id_map;
    m_hexahedron_id_map = in.m_hexahedron_id_map; 
    return *this;
}
    
UnstructuredGrid& UnstructuredGrid::operator=(UnstructuredGrid&& in) 
{
    m_elements = std::move(in.m_elements); m_edges = std::move(in.m_edges); m_triangles = std::move(in.m_triangles);
    m_quads = std::move(in.m_quads); m_tetrahedrons = std::move(in.m_tetrahedrons); m_pyramids = std::move(in.m_pyramids);
    m_hexahedrons = std::move(in.m_hexahedrons); m_node_id_map = std::move(in.m_node_id_map); 
    m_edge_id_map = std::move(in.m_edge_id_map); m_triangle_id_map = std::move(in.m_triangle_id_map); 
    m_quad_id_map = std::move(in.m_quad_id_map); m_tetrahedron_id_map = std::move(in.m_tetrahedron_id_map); 
    m_pyramid_id_map = std::move(in.m_pyramid_id_map); m_hexahedron_id_map = std::move(in.m_hexahedron_id_map); 
    return *this;
}

UnstructuredGrid::~UnstructuredGrid() 
{

}

bool UnstructuredGrid::read_gmsh(const char* filename) 
{
   return true;
}

// Element Creation Factories
UnstructuredGrid::NodeIter UnstructuredGrid::add_node(const coord& in_coord) 
{ 
    Node node(in_coord); 
   
    auto iter_pair = m_nodes.insert(node);
    auto iter = iter_pair.first;

    // if brand new node
    if(iter_pair.second)
    {
        node.set_id(get_next_id<Node>());            
        iter = m_nodes.insert(node).first;
        m_elements.push_back(iter->element());
        m_node_id_map.push_back(iter);
    }
    else
    {
        printf("Node already exists !!\n");
    }

    return iter;
}

UnstructuredGrid::EdgeIter UnstructuredGrid::add_edge(const UnstructuredGrid::Node* in_node1, const UnstructuredGrid::Node* in_node2)
{        
    UnstructuredGrid::Edge edge(in_node1, in_node2);
    
    auto iter_pair = m_edges.insert(edge);
    auto iter = iter_pair.first;
    
    // if brand new edge
    if(iter_pair.second)
    {
        const Edge* edge_ptr = &(*iter);
        in_node1->connect(edge_ptr); in_node2->connect(edge_ptr);
        edge.set_id(get_next_id<Edge>());
        m_elements.push_back(iter->element());
        m_edge_id_map.push_back(iter);
    }
    else
    {
        printf("Edge already exists !!\n");
    }

    return iter_pair.first;
}

UnstructuredGrid::EdgeIter UnstructuredGrid::add_edge(const UnstructuredGrid::NodeIter& in_node1, const UnstructuredGrid::NodeIter& in_node2)
{
    const Node* node1 = &(*in_node1);
    const Node* node2 = &(*in_node2);
    return add_edge(node1, node2);
}

UnstructuredGrid::TriangleIter UnstructuredGrid::add_triangle(const UnstructuredGrid::Edge* in_edge1, const UnstructuredGrid::Edge* in_edge2, const UnstructuredGrid::Edge* in_edge3)
{   
    Triangle triangle(in_edge1, in_edge2, in_edge3);
    auto iter_pair = m_triangles.insert(triangle);
    auto iter = iter_pair.first;

    // if brand new triangle
    if(iter_pair.second)
    {
        iter->set_id(get_next_id<Triangle>());
        const Triangle* triangle_ptr = &(*iter);
        
        in_edge1->connect(triangle_ptr); 
        in_edge2->connect(triangle_ptr);
        in_edge3->connect(triangle_ptr);

        m_elements.push_back(iter->element());
        m_triangle_id_map.push_back(iter);
    }
    else
    {
        printf("Triangle already exists !!\n");
    }

    return iter;
}

UnstructuredGrid::TriangleIter UnstructuredGrid::add_triangle(const UnstructuredGrid::EdgeIter& in_edge1, const UnstructuredGrid::EdgeIter& in_edge2, const UnstructuredGrid::EdgeIter& in_edge3)
{
    const Edge* edge1 = &(*in_edge1); const Edge* edge2 = &(*in_edge2);
    const Edge* edge3 = &(*in_edge3);
    return add_triangle(edge1, edge2, edge3);
}

UnstructuredGrid::QuadIter UnstructuredGrid::add_quad(const UnstructuredGrid::Edge* in_edge1, const UnstructuredGrid::Edge* in_edge2, const UnstructuredGrid::Edge* in_edge3, const UnstructuredGrid::Edge* in_edge4)
{        
    Quad quad(in_edge1, in_edge2, in_edge3, in_edge4);
    auto iter_pair = m_quads.insert(quad);
    auto iter = iter_pair.first;

    // if brand new quad
    if(iter_pair.second)
    {
        iter->set_id(get_next_id<Quad>());
        const Quad* quad_ptr = &(*iter);
            
        in_edge1->connect(quad_ptr); in_edge2->connect(quad_ptr);
        in_edge3->connect(quad_ptr); in_edge4->connect(quad_ptr);

        m_elements.push_back(iter->element());
        m_quad_id_map.push_back(iter);
    }
    return iter;
}

UnstructuredGrid::QuadIter UnstructuredGrid::add_quad(const EdgeIter& in_edge1, const EdgeIter& in_edge2, const EdgeIter& in_edge3, const EdgeIter& in_edge4)
{
    const Edge* edge1 = &(*in_edge1); const Edge* edge2 = &(*in_edge2);
    const Edge* edge3 = &(*in_edge3); const Edge* edge4 = &(*in_edge4);
    return add_quad(edge1, edge2, edge3, edge4);
}

UnstructuredGrid::TetrahedronIter UnstructuredGrid::add_tetrahedron(const TriangleIter& in_triangle1, const TriangleIter& in_triangle2, const TriangleIter& in_triangle3, const TriangleIter& in_triangle4)
{
    const Triangle* triangle1 = &(*in_triangle1);
    const Triangle* triangle2 = &(*in_triangle2);
    const Triangle* triangle3 = &(*in_triangle3);
    const Triangle* triangle4 = &(*in_triangle4);

    Tetrahedron tetrahedron(triangle1, triangle2, triangle3, triangle4);

    auto iter_pair = m_tetrahedrons.insert(tetrahedron);
    auto iter = iter_pair.first;

    // if brand new tetrahedron
    if(iter_pair.second)
    {
        iter->set_id(get_next_id<Tetrahedron>());
        const Tetrahedron* tetrahedron_ptr = &(*iter);

        in_triangle1->connect(tetrahedron_ptr); in_triangle2->connect(tetrahedron_ptr);
        in_triangle3->connect(tetrahedron_ptr); in_triangle4->connect(tetrahedron_ptr);

        m_elements.push_back(iter->element());
        m_tetrahedron_id_map.push_back(iter);
    }

    return iter;
}

UnstructuredGrid::PyramidIter UnstructuredGrid::add_pyramid(const QuadIter& in_base_quad, const TriangleIter& in_triangle1, const TriangleIter& in_triangle2, const TriangleIter& in_triangle3, const TriangleIter& in_triangle4)
{
    const Triangle* triangle1 = &(*in_triangle1);
    const Triangle* triangle2 = &(*in_triangle2);
    const Triangle* triangle3 = &(*in_triangle3);
    const Triangle* triangle4 = &(*in_triangle4);
    const Quad*     base_quad = &(*in_base_quad);

    Pyramid pyramid(base_quad, triangle1, triangle2, triangle3, triangle4);
    
    auto iter_pair = m_pyramids.insert(pyramid);
    auto iter = iter_pair.first;

    // if brand new pyramid
    if(iter_pair.second)
    {
        iter->set_id(get_next_id<Pyramid>());
        const Pyramid* pyramid_ptr = &(*iter);

        in_triangle1->connect(pyramid_ptr); in_triangle2->connect(pyramid_ptr);
        in_triangle3->connect(pyramid_ptr); in_triangle4->connect(pyramid_ptr); 

        m_elements.push_back(iter->element());
        m_pyramid_id_map.push_back(iter);
    }
    return iter;
}

UnstructuredGrid::HexahedronIter UnstructuredGrid::add_hexahedron(const QuadIter& in_quad1, const QuadIter& in_quad2, const QuadIter& in_quad3, const QuadIter& in_quad4, const QuadIter& in_quad5, const QuadIter& in_quad6)
{
    const Quad* quad1 = &(*in_quad1); const Quad* quad2 = &(*in_quad2);
    const Quad* quad3 = &(*in_quad3); const Quad* quad4 = &(*in_quad4);
    const Quad* quad5 = &(*in_quad5); const Quad* quad6 = &(*in_quad6);

    Hexahedron hexahedron(quad1, quad2, quad3, quad4, quad5, quad6); 

    auto iter_pair = m_hexahedrons.insert(hexahedron);
    auto iter = iter_pair.first;

    // if brand new hexahedron
    if(iter_pair.second)
    {
        iter->set_id(get_next_id<Hexahedron>());
        const Hexahedron* hexahedron_ptr = &(*iter);

        in_quad1->connect(hexahedron_ptr); in_quad2->connect(hexahedron_ptr);
        in_quad3->connect(hexahedron_ptr); in_quad4->connect(hexahedron_ptr);
        in_quad5->connect(hexahedron_ptr); in_quad6->connect(hexahedron_ptr);
 
        m_elements.push_back(iter->element());
        m_hexahedron_id_map.push_back(iter);
    }

    return iter;
}

UnstructuredGrid::NodeIter UnstructuredGrid::assign_node(const coord& in_coord, const uint64_t& id)
{ 
    Node node(in_coord); 
    
    auto iter_pair = m_nodes.insert(node);
    auto iter = iter_pair.first;

    // if brand new node
    if(iter_pair.second)
    {
        iter->set_id(id);            
        m_elements.push_back(iter->element());
        m_node_id_map.push_back(iter);
    }

    return iter;
}

UnstructuredGrid::EdgeIter UnstructuredGrid::assign_edge(const UnstructuredGrid::Node* in_node1, const UnstructuredGrid::Node* in_node2, const uint64_t& id)
{        
    UnstructuredGrid::Edge edge(in_node1, in_node2); 
    
    auto iter_pair = m_edges.insert(edge);
    auto iter = iter_pair.first;

    // if brand new edge
    if(iter_pair.second)
    {
        const Edge* edge_ptr = &(*iter);
        in_node1->connect(edge_ptr); in_node2->connect(edge_ptr);

        edge.set_id(id);
        m_elements.push_back(iter->element());
        m_edge_id_map.push_back(iter);
    }
    return iter;
}

void UnstructuredGrid::replace_node(const coord& old_coord, const coord& new_coord)
{
    Node old_node(old_coord);
    NodeIter node = m_nodes.find(old_node);
    if(node != m_nodes.end())
    {
        replace_node(node->get_id(), new_coord);
    }
    else
    {
        printf("Unable to Find and Replace Coordinates !!\n");
    }
}

// Element Modification Functions
/// @brief Replace a node (with node_id) with a new coordinates 
void UnstructuredGrid::replace_node(const uint64_t& node_id, const coord& in_coord)
{
    if(m_node_id_map.size() >= node_id) 
    {
      printf("Out Of Bound Access !!! Node ID not found !!\n");
      return;
    }

    NodeIter& old_node = m_node_id_map[node_id];
    
    if(*old_node == in_coord) return;

    NodeIter new_node = assign_node(in_coord, node_id);

    m_node_id_map[node_id] = new_node;

    const Node* common_node = &(*old_node);

    std::vector<const Edge*>& connected_edges =  old_node->get_edges();

    for(auto& edge : connected_edges)
    {
        EdgeIter iter;

        if((*edge)[0] == common_node) 
        {   
            (edge)->nodes[0] = &(*new_node);
        }
        
        else if((*edge)[1] == common_node)
        {
            (edge)->nodes[1] = &(*new_node);
        }
        else
        {
            printf("Edge not connected to the node !!\n");
        }

        const Edge* edge_ptr = &(*iter);
        new_node->connect(edge_ptr); new_node->connect(edge_ptr);
    }

    if(new_node->get_id() != node_id)
    {
        m_nodes.erase(*old_node);
        printf("Warning !!! A Node with the same Coordinates already exists !! Use replace_node(old_coord, new_coord) instead !!\n");
    }
}

std::vector<float> UnstructuredGrid::get_float_coords() const
{
    printf("Nodes size : %d\n", m_nodes.size());
    std::vector<float> coords_vec(m_nodes.size() * 3, 0.0f);

    for(auto& node : m_nodes)
    {
        const coord& coord = node;
        const uint32_t idx = static_cast<uint32_t>(node.get_id());
        coords_vec[idx * 3] = coord.x;
        coords_vec[idx * 3 + 1] = coord.y;
        coords_vec[idx * 3 + 2] = coord.z;
    }
    return coords_vec;
}
    
std::vector<uint32_t> UnstructuredGrid::get_edges() const
{
    std::vector<uint32_t> edge_indices(m_edges.size() * 2);

    uint32_t i = 0;
    for(auto& edge : m_edges)
    {
        auto nodes = edge.get_nodes();
        edge_indices[i] = static_cast<uint32_t>(nodes[0]->get_id());
        edge_indices[i + 1] = static_cast<uint32_t>(nodes[1]->get_id());
        i += 2;
    }
    return edge_indices;
}

std::vector<uint32_t> UnstructuredGrid::get_all_trias() const
{
    std::vector<uint32_t> tria_indices(m_triangles.size() * 3);
    printf("Triangles: %d\n", m_triangles.size());

    uint32_t i = 0;
    for(auto& tria : m_triangles)
    {
        auto nodes = tria.get_nodes_array();
        tria_indices[i] = static_cast<uint32_t>(nodes[0]->get_id());
        tria_indices[i + 1] = static_cast<uint32_t>(nodes[1]->get_id());
        tria_indices[i + 2] = static_cast<uint32_t>(nodes[2]->get_id());
        i += 3;
    }

    return tria_indices;
}