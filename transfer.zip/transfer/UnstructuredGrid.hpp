#ifndef GP_UNSTRUCTUREDGRID_HPP
#define GP_UNSTRUCTUREDGRID_HPP

#include <cstdint>

#include <array>
#include <string>
#include <vector>
#include <set>
#include <map>
#include <unordered_map>
#include <type_traits>

#include <memory>
#include <algorithm>

#include <assert.h>

#include "common_headers/common/coord.hpp"

#include "common_headers/common/gp_std_lib/gp_uuid.hpp"
#include "common_headers/common/gp_std_lib/gp_optional.hpp"

#include "../common_components/GridTraits.hpp"


class IR_UnstructuredGrid;

/// @brief Unstructured Grid 
/// @note Class to represent an unstructured grid with detailed connectivity information
/// @note The class is adjacency graph like structure with heirarchal connectivity from nodes to edges to faces to volumes
class UnstructuredGrid : public Generic::Domain
{   
        public: 
            class Element;
            class Node;
            class Edge;
            class HigherOrderEdge;
            class Triangle;
            class Quad; 
            class Tetrahedron; // Irregular Tetrahedron
            class Pyramid; // Quad base with a 4 triangle
            class Hexahedron;

            using NodeIter = std::set<Node>::iterator;
            using EdgeIter = std::set<Edge>::iterator;
            using TriangleIter = std::set<Triangle>::iterator;
            using QuadIter = std::set<Quad>::iterator;
            using TetrahedronIter = std::set<Tetrahedron>::iterator;
            using PyramidIter = std::set<Pyramid>::iterator;
            using HexahedronIter = std::set<Hexahedron>::iterator;

            template<typename ElementType>
            struct ID
            {
                static_assert(std::is_base_of<Element, ElementType>::value, "T must be derived from Element");

                explicit ID(const ElementType* in) : element(in) {}
                        
                operator const ElementType*() const { return element; }

                bool operator<(const ID& in)  const { return in.element->get_id() < element->get_id(); }
                bool operator>(const ID& in)  const { return in.element->get_id() > element->get_id(); }
                bool operator==(const ID& in) const { return in.element->get_id() == element->get_id(); }
                bool operator!=(const ID& in) const { return in.element->get_id() != element->get_id(); }

                private:
                const ElementType* element;
            };
            
            using NodeID = ID<Node>;
            using EdgeID = ID<Edge>;
            using QuadID = ID<Quad>;
            using TriangleID = ID<Triangle>;
            using TetrahedronID = ID<Tetrahedron>;
            using PyramidID = ID<Pyramid>;
            using HexahedronID = ID<Hexahedron>;

            ///  ******************  Implementation of Element classes **********************
            class Element : public Generic::Element
            {
                public:
                explicit Element(const Traits::Dimension& in_dimension, const Traits::ElementType& in_type) : Generic::Element(in_dimension, in_type) {}
                Element(const Element& in) : Generic::Element(in) {}
                Element(Element&& in) : Generic::Element(in) {}
                Element& operator=(const Element& in) { dim = in.dim; id = in.id; return *this; }
                Element& operator=(Element&& in) { dim = in.dim; id = in.id; return *this; }
                
                virtual std::shared_ptr<Element> clone() const = 0;
                virtual std::vector<const Node*> get_nodes() const = 0;
                std::vector<const coord*> get_coords() const override { return std::vector<const coord*>(); }

                const UnstructuredGrid::Element* element() const { return (static_cast<const UnstructuredGrid::Element*>(this)); }
                
                template<typename T>
                bool is() const 
                { 
                    static_assert(std::is_base_of<Element, T>::value, "T must be derived from Element");
                    return dynamic_cast<const T*>(this) != nullptr; 
                }

                template<typename T>
                const T* as() const 
                {  
                    static_assert(std::is_base_of<Element, T>::value, "T must be derived from Element");
                    return dynamic_cast<const T*>(this); 
                }

                template<typename T>
                T* as() 
                {
                    static_assert(std::is_base_of<Element, T>::value, "T must be derived from Element"); 
                    return dynamic_cast<T*>(this); 
                }

                virtual ~Element() override = default;

                friend class UnstructuredGrid;
            };

            class Node : public Element
            {
                public:
                Node(const Node& in) : Element(in), node_coord(in.node_coord) , belonging_edges(in.belonging_edges) {}
                Node(Node&& in) noexcept : Element(in), node_coord(std::move(in.node_coord)) , belonging_edges(std::move(in.belonging_edges)) {}

                Node& operator=(const Node& in) { Element::operator=(in); node_coord = in.node_coord; belonging_edges = in.belonging_edges; return *this; }
                Node& operator=(Node&& in) { Element::operator=(in); node_coord = std::move(in.node_coord); belonging_edges = std::move(in.belonging_edges); return *this; }

                bool operator<(const Node& in) const { return node_coord < in.node_coord; }
                bool operator>(const Node& in) const { return in.node_coord < node_coord; }
   
                bool operator==(const coord& in) const { return (node_coord.x == in.x && node_coord.y == in.y && node_coord.z == in.z); }
                bool operator!=(const coord& in) const { return (node_coord.x != in.x || node_coord.y != in.y || node_coord.z != in.z); }
                
                operator coord&()  { return node_coord; }
                operator const coord&() const { return node_coord; }

                const double& x() const { return node_coord.x; }
                const double& y() const { return node_coord.y; }
                const double& z() const { return node_coord.z; }

                std::shared_ptr<Element> clone() const override final { return std::make_shared<Node>(*this); }
                void connect(const Edge* in_edge) const { belonging_edges.push_back(in_edge); }

                std::vector<const Node*>  get_nodes()  const override final { std::vector<const Node*> nodes; nodes.push_back(this); return nodes; }
                std::vector<const coord*> get_coords() const override final { return { &node_coord };  }
                std::vector<const Edge*>& get_edges()  const { return belonging_edges; }

                bool is_part_of(const Edge* in_edge) const { return std::find(belonging_edges.begin(), belonging_edges.end(), in_edge) != belonging_edges.end(); }

                ~Node() override final = default;

                private:
                friend class UnstructuredGrid;  
                explicit Node(const coord& in_coord) : Element(Traits::Point, Traits::Node), node_coord(in_coord) {}
                
                private:
                coord node_coord;
                mutable std::vector<const Edge*> belonging_edges;
            };

            class Edge : public Element
            {
                public:
                Edge(const Edge& in) : Element(in), nodes(in.nodes) , belonging_triangles(in.belonging_triangles), belonging_quads(in.belonging_quads) {}
                Edge(Edge&& in) noexcept : Element(in), nodes(std::move(in.nodes)) , belonging_triangles(std::move(in.belonging_triangles)), belonging_quads(std::move(in.belonging_quads)) {}
                
                bool is_valid() const
                {
                    // Validate the edge
                    if(nodes[0] == nodes[1]) { printf("Invalid Edge: Coincident Nodes"); return false; }
                    return true;
                }

                Edge& operator=(const Edge& in) { Element::operator=(in); nodes = in.nodes; return *this; }
                Edge& operator=(Edge&& in) { Element::operator=(in); nodes = std::move(in.nodes); return *this; }

                bool operator==(const Edge& in) const { return gp_std::compare_equal(get_sorted_ids(), in.get_sorted_ids()); }
                bool operator!=(const Edge& in) const { return !(*this == in); }

                bool operator<(const Edge& in) const { return gp_std::compare_less(get_sorted_ids(), in.get_sorted_ids()); }
                bool operator>(const Edge& in) const { return ((in < *this)); }

                std::shared_ptr<Element> clone() const override final { return std::make_shared<Edge>(*this); }

                void connect(const Triangle* in_triangle) const { belonging_triangles.push_back(in_triangle); }
                void connect(const Quad* in_quad) const { belonging_quads.push_back(in_quad); }

                const Node*& operator[](const uint8_t& index)  { return nodes[index]; }
                const Node* const & operator[](const uint8_t& index) const { return nodes[index]; }

                std::vector<const Node*> get_nodes() const override final { std::vector<const Node*> nodes; nodes.push_back(this->nodes[0]); nodes.push_back(this->nodes[1]); return nodes; }
                std::vector<const coord*> get_coords() const override final { std::vector<const coord*> coords; coords.push_back(&nodes[0]->node_coord); coords.push_back(&nodes[1]->node_coord); return coords; }
                std::vector<const Triangle*>& get_triangles() const { return belonging_triangles; }
                std::vector<const Quad*>& get_quads() const { return belonging_quads; }
                std::array<uint64_t, 2> get_sorted_ids() const { std::array<uint64_t, 2> ids = {nodes[0]->get_id(), nodes[1]->get_id()}; std::sort(ids.begin(), ids.end()); return ids; }
                double length() const { const coord& n1 = *nodes[0]; const coord& n2 = *nodes[1]; return std::sqrt((n1.x - n2.x)*(n1.x - n2.x) + (n1.y - n2.y)*(n1.y - n2.y) + (n1.z - n2.z)*(n1.z - n2.z)); }

                std::array<const Node*, 2>::const_iterator begin() const { return nodes.cbegin(); }
                std::array<const Node*, 2>::const_iterator end()  const  { return nodes.cend(); }

                ~Edge() override final = default;

                private:
                friend class UnstructuredGrid;
                
                explicit Edge(const Node* in_node1, const Node* in_node2) : Element(Traits::Curve, Traits::Edge)
                {
                     nodes[0] = in_node1; nodes[1] = in_node2; 
                }

                gp_std::optional<const Triangle*&> find_connection(const Triangle* in_triangle) const
                {
                    auto it = std::find(belonging_triangles.begin(), belonging_triangles.end(), in_triangle);
                    if(it != belonging_triangles.end()) return *it;
                    return gp_std::nullopt;
                }

                gp_std::optional<const Quad*&> find_connection(const Quad* in_quad) const
                {
                    auto it = std::find(belonging_quads.begin(), belonging_quads.end(), in_quad);
                    if(it != belonging_quads.end()) return *it;
                    return gp_std::nullopt;
                }
                
                private:
                friend UnstructuredGrid;
                mutable std::array<const Node*, 2> nodes;
                mutable std::vector<const Triangle*> belonging_triangles;
                mutable std::vector<const Quad*> belonging_quads;
            };

            class HigherOrderEdge : public Element
            {
                public:

                explicit HigherOrderEdge(const std::vector<const Node*>& in_nodes) : Element(Traits::Curve, Traits::HigherOrderEdge), nodes(in_nodes) {}

                HigherOrderEdge(const HigherOrderEdge& in) : Element(in), nodes(in.nodes) {}
                HigherOrderEdge(HigherOrderEdge&& in) noexcept : Element(in), nodes(std::move(in.nodes)) {}

                HigherOrderEdge& operator=(const HigherOrderEdge& in) { Element::operator=(in); nodes = in.nodes; return *this; }
                HigherOrderEdge& operator=(HigherOrderEdge&& in) { Element::operator=(in); nodes = std::move(in.nodes); return *this; }

                bool operator==(const HigherOrderEdge& in) const { return gp_std::compare_equal(get_sorted_ids(), in.get_sorted_ids()); }
                bool operator!=(const HigherOrderEdge& in) const { return !(*this == in); }

                bool operator<(const HigherOrderEdge& in) const { return gp_std::compare_less(get_sorted_ids(), in.get_sorted_ids()); }
                bool operator>(const HigherOrderEdge& in) const { return (( in < *this)); }

                std::vector<const Node*>::const_iterator begin() const { return nodes.cbegin(); }
                std::vector<const Node*>::const_iterator end()  const  { return nodes.cend(); }

                const Node* const & operator[](const uint8_t& index) const { return nodes[index]; }

                std::vector<const Node*> get_nodes() const override final { std::vector<const Node*> nodes; nodes.push_back(this->nodes[0]); nodes.push_back(this->nodes[1]); return nodes; }
                std::shared_ptr<Element> clone() const override final { return std::make_shared<HigherOrderEdge>(*this); }
                std::vector<uint64_t> get_sorted_ids() const
                {
                    std::vector<uint64_t> ids;
                    for(auto& node : nodes) ids.push_back(node->get_id());
                    std::sort(ids.begin(), ids.end());
                    return ids;
                }
                
                //mutable std::vector<const Triangle*> belonging_higher_order_triangles;
                //mutable std::vector<const Quad*> belonging_higher_order_quads;

                ~HigherOrderEdge() override final = default;

                private:
                std::vector<const Node*> nodes;
            }; 


            class Triangle : public Element
            {
                public:
                Triangle(const Triangle& in) : Element(in), edges(in.edges) {}
                Triangle(Triangle&& in) noexcept : Element(in), edges(std::move(in.edges)) {}

                bool is_valid() const
                {
                    // Validate the triangle
                    std::array<const Node*, 6> nodes;
                    uint32_t i = 0;
                    for(const Edge* const & edge : edges)
                    {
                        for(const Node* const & node : *edge)
                        {
                            nodes[i] = node;
                            i++;
                        }
                    }
                    std::set<const Node*> unique_nodes(nodes.begin(), nodes.end());

                    if(unique_nodes.size() < 3)      { printf("Invalid Triangle: Excess Coincident Nodes");  return false; }
                    else if(unique_nodes.size() > 3) { printf("Invalid Triangle: Missing Coincident Nodes"); return false; }
                    
                    return true;
                }
                
                double area()
                {
                     //Area
                     std::array<const Node*, 3> nodes = get_nodes_array();
                     const coord& n1 = *nodes[0];
                     const coord& n2 = *nodes[1];
                     const coord& n3 = *nodes[2];
                     return 0.5 * std::abs((n1.x * (n2.y - n3.y) + n2.x * (n3.y - n1.y) + n3.x * (n1.y - n2.y)));
                }

                std::array<const Node* , 3> get_nodes_array() const 
                {
                    return {(*edges[0])[0], (*edges[1])[0], (*edges[2])[0]};
                }

                Triangle& operator=(const Triangle& in) { Element::operator=(in); edges = in.edges; return *this; }
                Triangle& operator=(Triangle&& in) { Element::operator=(in); edges = std::move(in.edges); return *this; }

                bool operator==(const Triangle& in) const { return gp_std::compare_equal(get_sorted_ids(), in.get_sorted_ids()); }
                bool operator!=(const Triangle& in) const { return !(*this == in); }

                bool operator<(const Triangle& in) const { return gp_std::compare_less(get_sorted_ids(), in.get_sorted_ids()); }
                bool operator>(const Triangle& in) const { return ((in < *this)); }

                // Actions
                void connect(const Tetrahedron* in_tetrahedron) const { belonging_tetrahedrons.push_back(in_tetrahedron); }
                void connect(const Pyramid* in_pyramid) const { belonging_pyramids.push_back(in_pyramid); }
                std::shared_ptr<Element> clone() const override final { return std::make_shared<Triangle>(*this); }  
                
                const Edge* const & operator[](const uint8_t& index) { return edges[index]; }

                std::vector<const Node*> get_nodes() const override final 
                { 
                    std::array<const Node*, 6> nodes;
                    uint32_t i = 0;
                    for(auto& edge : edges)
                    {
                        nodes[i]  =  ((*edge)[0]);
                        nodes[i+1] = ((*edge)[1]);
                        i += 2;
                    }
                    std::set<const Node*> unique_nodes_set(nodes.begin(), nodes.end());
                    std::vector<const Node*> unique_nodes(unique_nodes_set.begin(), unique_nodes_set.end());
                    return unique_nodes;
                } 

                std::vector<const coord*> get_coords() const override final 
                { 
                    std::array<const Node*, 6> nodes;
                    uint32_t i = 0;
                    for(auto& edge : edges)
                    {
                        nodes[i]  =  ((*edge)[0]);
                        nodes[i+1] = ((*edge)[1]);
                        i += 2;
                    }
                    std::set<const Node*> unique_nodes_set(nodes.begin(), nodes.end());
                    std::vector<const Node*> unique_nodes(unique_nodes_set.begin(), unique_nodes_set.end());
                    std::vector<const coord*> coords;
                    for(auto& node : unique_nodes) coords.push_back(&(node->node_coord));
                    return coords;
                } 

                std::array<uint64_t, 3> get_sorted_ids() const 
                { 
                    std::array<uint64_t, 3> ids = {edges[0]->get_id(), edges[1]->get_id(), edges[2]->get_id()};
                    std::sort(ids.begin(), ids.end());
                    return ids; 
                }

                std::vector<const Tetrahedron*>& get_tetrahedrons() const { return belonging_tetrahedrons; }
                std::vector<const Pyramid*>& get_pyramids()         const { return belonging_pyramids; }

                gp_std::optional<const Tetrahedron*&> find_connection(const Tetrahedron* in_tetrahedron) const
                {
                    auto it = std::find(belonging_tetrahedrons.begin(), belonging_tetrahedrons.end(), in_tetrahedron);
                    if(it != belonging_tetrahedrons.end()) return *it;
                    return gp_std::nullopt;
                }

                gp_std::optional<const Pyramid*&> find_connection(const Pyramid* in_pyramid) const
                {
                    auto it = std::find(belonging_pyramids.begin(), belonging_pyramids.end(), in_pyramid);
                    if(it != belonging_pyramids.end()) return *it;
                    return gp_std::nullopt;
                }

                std::array<const Edge*, 3>::const_iterator begin() const { return edges.cbegin(); }
                std::array<const Edge*, 3>::const_iterator end() const  { return edges.cend();   }

                bool is_boundary() const { return (belonging_tetrahedrons.size() + belonging_pyramids.size() <= 1); } 

                ~Triangle() override final = default;   

                private:
                friend UnstructuredGrid;
                explicit Triangle(const Edge* in_edge1, const Edge* in_edge2, const Edge* in_edge3) : Element(Traits::Polygon, Traits::Triangle) 
                { 
                    edges[0] = in_edge1; edges[1] = in_edge2; edges[2] = in_edge3; 
                }

                private:
                std::array<const Edge*, 3> edges;
                mutable std::vector<const Tetrahedron*> belonging_tetrahedrons;
                mutable std::vector<const Pyramid*> belonging_pyramids;
            };

            class Quad : public Element
            {
                public:
                Quad(const Quad& in) : Element(in), edges(in.edges) {}
                Quad(Quad&& in) noexcept : Element(in), edges(std::move(in.edges)) {}
                
                Quad& operator=(const Quad& in) { Element::operator=(in); edges = in.edges; return *this; }
                Quad& operator=(Quad&& in) { Element::operator=(in); edges = std::move(in.edges); return *this; }

                bool operator==(const Quad& in) const { return gp_std::compare_equal(get_sorted_ids(), in.get_sorted_ids()); }
                bool operator!=(const Quad& in) const { return !(*this == in); }

                bool operator<(const Quad& in) const { return gp_std::compare_less(get_sorted_ids(), in.get_sorted_ids()); }
                bool operator>(const Quad& in) const { return ((in < *this)); }

                std::shared_ptr<Element> clone() const override final { return std::make_shared<Quad>(*this); }
                void connect(const Hexahedron* in_hexahedron) const { belonging_hexahedrons.push_back(in_hexahedron); }

                const Edge* const & operator[](const uint8_t& index) const { return edges[index]; }

                std::array<const Node*, 4> get_nodes_array()
                {
                    return {(*edges[0])[0], (*edges[1])[0], (*edges[2])[0], (*edges[3])[0]};
                }

                std::vector<const Node*> get_nodes() const  override final 
                { 
                    std::vector<const Node*> nodes(8);
                    uint32_t i = 0;
                    for(auto& edge : edges)
                    {
                        nodes[i]  =  ((*edge)[0]);
                        nodes[i+1] = ((*edge)[1]);
                        i += 2;
                    }
                }

                std::vector<const coord*> get_coords() const override final 
                { 
                    std::vector<const Node*> nodes(8);
                    uint32_t i = 0;
                    for(auto& edge : edges)
                    {
                        nodes[i]  =  ((*edge)[0]);
                        nodes[i+1] = ((*edge)[1]);
                        i += 2;
                    }
                    std::set<const Node*> unique_nodes_set(nodes.begin(), nodes.end());
                    std::vector<const Node*> unique_nodes(unique_nodes_set.begin(), unique_nodes_set.end());
                    std::vector<const coord*> coords;
                    for(auto& node : unique_nodes) coords.push_back(&(node->node_coord));
                    return coords;
                }

                std::vector<const Hexahedron*>& get_hexahedrons() const { return belonging_hexahedrons; }

                std::array<const Edge*, 4>::const_iterator begin() const  { return edges.cbegin(); }
                std::array<const Edge*, 4>::const_iterator end()   const { return edges.cend();   }

                gp_std::optional<const Hexahedron*&> find_connection(const Hexahedron* in_hexahedron) const
                {
                    auto it = std::find(belonging_hexahedrons.begin(), belonging_hexahedrons.end(), in_hexahedron);
                    if(it != belonging_hexahedrons.end()) return *it;
                    return gp_std::nullopt;
                }

                std::array<uint64_t, 4> get_sorted_ids() const 
                { 
                    std::array<uint64_t, 4> ids = {edges[0]->get_id(), edges[1]->get_id(), 
                                                   edges[2]->get_id(), edges[3]->get_id()};
                    std::sort(ids.begin(), ids.end());
                    return ids; 
                }

                bool is_valid() const
                {
                    // Validate the quad
                    std::array<const Node*, 8> nodes;
                    uint32_t i = 0;
                    for(auto& edge : edges)
                    {
                        for(auto& node : *edge)
                        {
                            nodes[i] = node;
                            i++;
                        }
                    }
                    std::set<const Node*> unique_nodes(nodes.begin(), nodes.end());
                    if(unique_nodes.size() < 4)      { printf("Invalid Quad: Excess Coincident Nodes");  return false; }
                    else if(unique_nodes.size() > 4) { printf("Invalid Quad: Missing Coincident Nodes"); return false; }
                    
                    return true;
                }

                bool is_boundary() const { return (belonging_hexahedrons.size() <= 1); }

               ~Quad() override final = default;

                private:
               
                explicit Quad(const Edge* in_edge1, const Edge* in_edge2, const Edge* in_edge3, const Edge* in_edge4) : Element(Traits::Polygon, Traits::Quad) 
                {
                    edges[0] = in_edge1; edges[1] = in_edge2; edges[2] = in_edge3; edges[3] = in_edge4;  
                }
                
                private:
                friend UnstructuredGrid;
                std::array<const Edge*, 4> edges;
                mutable std::vector<const Hexahedron*> belonging_hexahedrons;
            };

            class Tetrahedron : public Element
            {
                public:
                explicit Tetrahedron(const Triangle* in_triangle1, const Triangle* in_triangle2, const Triangle* in_triangle3, const Triangle* in_triangle4) : Element(Traits::Volume, Traits::Tetrahedron) 
                {
                    std::array<TriangleID, 4> sorted_triangles = {TriangleID(in_triangle1), TriangleID(in_triangle2), TriangleID(in_triangle3), TriangleID(in_triangle4)};
                    std::sort(sorted_triangles.begin(), sorted_triangles.end());
                    triangles[0] = sorted_triangles[0]; triangles[1] = sorted_triangles[1]; triangles[2] = sorted_triangles[2]; triangles[3] = sorted_triangles[3];
                }
                Tetrahedron(const Tetrahedron& in) : Element(in), triangles(in.triangles) {}
                Tetrahedron(Tetrahedron&& in) noexcept : Element(in), triangles(std::move(in.triangles)) {}

                Tetrahedron& operator=(const Tetrahedron& in) { Element::operator=(in); triangles = in.triangles; return *this; }
                Tetrahedron& operator=(Tetrahedron&& in) { Element::operator=(in); triangles = std::move(in.triangles); return *this; }

                bool operator==(const Tetrahedron& in) const { return gp_std::compare_equal(get_sorted_ids(), in.get_sorted_ids()); }
                bool operator!=(const Tetrahedron& in) const { return !(*this == in); }

                bool operator<(const Tetrahedron& in) const { return gp_std::compare_less(get_sorted_ids(), in.get_sorted_ids()); }
                bool operator>(const Tetrahedron& in) const { return ((in < *this)); }

                std::shared_ptr<Element> clone() const override final { return std::make_shared<Tetrahedron>(*this); }

                const Triangle* const & operator[](const uint8_t& index) { return triangles[index]; }

                std::vector<const Node*> get_nodes() const override final 
                { 
                    std::vector<const Node*> nodes;
                    uint32_t i = 0;
                    for(auto& triangle : triangles)
                    {
                       std::array<const Node*, 3> triangle_nodes = triangle->get_nodes_array(); 
                       for(auto& node : triangle_nodes) nodes.push_back(node);
                    }

                    std::set<const Node*> unique_nodes_set(nodes.begin(), nodes.end());
                    std::vector<const Node*> unique_nodes(unique_nodes_set.begin(), unique_nodes_set.end());
                    return unique_nodes;
                }

                std::vector<const coord*> get_coords() const override final 
                { 
                    std::vector<const coord*> coords;
                    for(auto& node : get_nodes()) coords.push_back(&(node->node_coord));
                    return coords;
                }

                std::array<uint64_t, 4> get_sorted_ids() const 
                { 
                    std::array<uint64_t, 4> ids = { triangles[0]->get_id(), triangles[1]->get_id(), 
                                                    triangles[2]->get_id(), triangles[3]->get_id()};
                    return ids; 
                }

                bool is_valid() const
                {
                    // Validate the Tetrahedron
                    std::array<const Edge*, 12> edges;
                    uint32_t i = 0;
                    for(auto& triangle : triangles)
                    {
                        for(auto& edge : *triangle)
                        {
                            edges[i] = edge;
                        }
                    }

                    std::set<const Edge*> unique_edges(edges.begin(), edges.end());
                    if(unique_edges.size() < 6)      { printf("Invalid Pyramid: Excess Coincident Edges");  return false; }
                    else if(unique_edges.size() > 6) { printf("Invalid Pyramid: Missing Coincident Edges"); return false; }
                    
                    return true;
                }

                std::array<const Triangle*, 4>::iterator begin() { return triangles.begin(); }
                std::array<const Triangle*, 4>::iterator end()   { return triangles.end();   }

                ~Tetrahedron() override final = default;

                private:
                std::array<const Triangle*, 4> triangles;
            };

            // Square Pyramid
            class Pyramid : public Element
            {
                public:
                explicit Pyramid(const Quad* in_quad, const Triangle* in_triangle1, const Triangle* in_triangle2, const Triangle* in_triangle3, const Triangle* in_triangle4) : Element(Traits::Volume, Traits::Pyramid)
                {
                    std::array<TriangleID, 4> sorted_triangles = {TriangleID(in_triangle1), TriangleID(in_triangle2), TriangleID(in_triangle3), TriangleID(in_triangle4)};
                    std::sort(sorted_triangles.begin(), sorted_triangles.end());
                    base_quad = in_quad;
                    triangles[0] = sorted_triangles[0]; triangles[1] = sorted_triangles[1]; triangles[2] = sorted_triangles[2]; triangles[3] = sorted_triangles[3];
                }
                Pyramid(const Pyramid& in) : Element(in), triangles(in.triangles) {}
                Pyramid(Pyramid&& in) noexcept : Element(in), triangles(std::move(in.triangles)) {}

                Pyramid& operator=(const Pyramid& in) { Element::operator=(in); triangles = in.triangles; return *this; }
                Pyramid& operator=(Pyramid&& in) { Element::operator=(in); triangles = std::move(in.triangles); return *this; }

                bool operator==(const Pyramid& in) const { return gp_std::compare_equal(get_sorted_ids(), in.get_sorted_ids()); }
                bool operator!=(const Pyramid& in) const { return !(*this == in); }

                bool operator<(const Pyramid& in) const { return gp_std::compare_less(get_sorted_ids(), in.get_sorted_ids()); }
                bool operator>(const Pyramid& in) const { return (in < (*this)); }

                std::shared_ptr<Element> clone() const override final { return std::make_shared<Pyramid>(*this); }

                const Triangle* const & operator[](const uint8_t& index) { return triangles[index]; }

                std::vector<const Node*> get_nodes() const override final 
                { 
                    std::vector<const Node*> nodes(12); 
                    uint32_t i = 0;
                    for(auto& triangle : triangles)
                    {
                        for(auto& edge : *triangle)
                        {
                            nodes[i]  =  ((*edge)[0]);
                            nodes[i+1] = ((*edge)[1]);
                            i += 2;
                        }
                    }

                    return nodes;
                }

                std::vector<const coord*> get_coords() const override final 
                { 
                    std::array<const Node*, 12> nodes;
                    uint32_t i = 0;
                    for(auto& triangle : triangles)
                    {
                        for(auto& edge : *triangle)
                        {
                            nodes[i]  =  ((*edge)[0]);
                            nodes[i+1] = ((*edge)[1]);
                            i += 2;
                        }
                    }
                    std::set<const Node*> unique_nodes_set(nodes.begin(), nodes.end());
                    std::vector<const Node*> unique_nodes(unique_nodes_set.begin(), unique_nodes_set.end());
                    std::vector<const coord*> coords;
                    for(auto& node : unique_nodes) coords.push_back(&(node->node_coord));
                    return coords;
                }

                std::array<uint64_t, 5> get_sorted_ids() const 
                { 
                    std::array<uint64_t, 5> ids = { base_quad->get_id(), triangles[0]->get_id(), triangles[1]->get_id(), 
                                                    triangles[2]->get_id(), triangles[3]->get_id()};
                    return ids; 
                }

                bool is_valid() const
                {
                     // Validate the pyramid
                    std::array<const Edge*, 16> edges;
                    uint32_t i = 0;
                    for(auto& triangle : triangles)
                    {
                        for(auto& edge : *triangle)
                        {
                            edges[i++] = edge;
                        }
                    }

                    for(auto& edge : *base_quad)
                    {
                        edges[i++] = edge;
                    }

                    std::set<const Edge*> unique_edges(edges.begin(), edges.end());
                    if(unique_edges.size() < 8)      { printf("Invalid Square Pyramid: Excess Coincident Edges");  return false; }
                    else if(unique_edges.size() > 8) { printf("Invalid Square Pyramid: Missing Coincident Edges"); return false; }
                    
                    return true;
                }

                std::array<const Triangle*, 4>::iterator begin() { return triangles.begin(); }
                std::array<const Triangle*, 4>::iterator end()   { return triangles.end();   }

                ~Pyramid() override final = default;

                private:
                const Quad* base_quad;
                std::array<const Triangle*, 4> triangles;
            };

            class Hexahedron : public Element
            {
                public:
                explicit Hexahedron(const Quad* in_quad1, const Quad* in_quad2, const Quad* in_quad3, const Quad* in_quad4, const Quad* in_quad5, const Quad* in_quad6) : Element(Traits::Volume, Traits::Hexahedron) 
                { 
                    std::array<QuadID, 6> sorted_quads = {QuadID(in_quad1), QuadID(in_quad2), QuadID(in_quad3), QuadID(in_quad4), QuadID(in_quad5), QuadID(in_quad6)};                    
                    std::sort(sorted_quads.begin(), sorted_quads.end());
                    quads[0] = sorted_quads[0]; quads[1] = sorted_quads[1]; quads[2] = sorted_quads[2]; 
                    quads[3] = sorted_quads[3]; quads[4] = sorted_quads[4]; quads[5] = sorted_quads[5];
                }
                
                Hexahedron(const Hexahedron& in) : Element(in), quads(in.quads) {}
                Hexahedron(Hexahedron&& in) noexcept: Element(in), quads(std::move(in.quads)) {}

                Hexahedron& operator=(const Hexahedron& in) { Element::operator=(in); quads = in.quads; return *this; }
                Hexahedron& operator=(Hexahedron&& in) { Element::operator=(in); quads = std::move(in.quads); return *this; }

                bool operator==(const Hexahedron& in) const { return gp_std::compare_equal(get_sorted_ids(), in.get_sorted_ids()); }
                bool operator!=(const Hexahedron& in) const { return !(*this == in); }

                bool operator<(const Hexahedron& in) const { return gp_std::compare_less(get_sorted_ids(), in.get_sorted_ids()); }
                bool operator>(const Hexahedron& in) const { return (in < *this); }

                std::shared_ptr<Element> clone() const override final { return std::make_shared<Hexahedron>(*this); }

                const Quad* const& operator[](const uint8_t& index) { return quads[index]; }

                std::vector<const Node*> get_nodes() const override final 
                { 
                    std::vector<const Node*> nodes(24);
                    uint32_t i = 0; 
                    for(auto& quad : quads)
                    {
                        for(auto& edge : *quad)
                        {
                            nodes[i]  =  ((*edge)[0]);
                            nodes[i+1] = ((*edge)[1]);
                            i += 2;
                        }
                    }
                }

                std::array<uint64_t, 6> get_sorted_ids() const 
                { 
                    std::array<uint64_t, 6> ids = { quads[0]->get_id(), quads[1]->get_id(), 
                                                    quads[2]->get_id(), quads[3]->get_id(), quads[4]->get_id(), quads[5]->get_id() };
                    return ids; 
                }
                
                bool is_valid() const 
                {
                     // Validate the pyramid
                    std::array<const Edge*, 24> edges;
                    uint32_t i = 0;
                    for(auto& quad : quads)
                    {
                        for(auto& edge : *quad)
                        {
                            edges[i] = edge;
                        }
                    }
                    std::set<const Edge*> unique_edges(edges.begin(), edges.end());
                    if(unique_edges.size() < 12)      { printf("Invalid Pyramid: Excess Coincident Edges");  return false; }
                    else if(unique_edges.size() > 12) { printf("Invalid Pyramid: Missing Coincident Edges"); return false; }
                    
                    return true;
                }

                std::array<const Quad*, 6>::iterator begin() { return quads.begin(); }
                std::array<const Quad*, 6>::iterator end()   { return quads.end();   }

                ~Hexahedron() override final = default;
                private:
                std::array<const Quad*, 6> quads;
            };

            ///  ******************  Implementation of Element classes End **********************

    /// Memeber functions of UnstructuredGrid class
    UnstructuredGrid(const char* name);
    UnstructuredGrid(const UnstructuredGrid& in) ;
    UnstructuredGrid(UnstructuredGrid&& in);
   ~UnstructuredGrid() override final;
      
    UnstructuredGrid& operator=(const UnstructuredGrid& in) ;
    UnstructuredGrid& operator=(UnstructuredGrid&& in);
    
    // Load an Intermediate Representation Grid
    void load_ir_grid(const IR_UnstructuredGrid& in);

    // File I/O Functions
    bool read_gmsh(const char* file_name);
    void load_gmsh(const char* filename);

    // Element Creation Factories. They return an iterator to the created element
    NodeIter add_node(const coord& in_coord);

    EdgeIter add_edge(const Node* in_node1, const Node* in_node2);
    EdgeIter add_edge(const NodeIter& in_node1, const NodeIter& in_node2);

    TriangleIter add_triangle(const Edge* in_edge1, const Edge* in_edge2, const Edge* in_edge3);
    TriangleIter add_triangle(const EdgeIter& in_edge1, const EdgeIter& in_edge2, const EdgeIter& in_edge3);

    QuadIter add_quad(const Edge* in_edge1, const Edge* in_edge2, const Edge* in_edge3, const Edge* in_edge4);
    QuadIter add_quad(const EdgeIter& in_edge1, const EdgeIter& in_edge2, const EdgeIter& in_edge3, const EdgeIter& in_edge4);

    TetrahedronIter add_tetrahedron(const TriangleIter& in_triangle1, const TriangleIter& in_triangle2, const TriangleIter& in_triangle3, const TriangleIter& in_triangle4);
    PyramidIter     add_pyramid(const QuadIter& in_base_quad, const TriangleIter& in_triangle1, const TriangleIter& in_triangle2, const TriangleIter& in_triangle3, const TriangleIter& in_triangle4);
    HexahedronIter  add_hexahedron(const QuadIter& in_quad1, const QuadIter& in_quad2, const QuadIter& in_quad3, const QuadIter& in_quad4, const QuadIter& in_quad5, const QuadIter& in_quad6);
    
    // Element Modification Functions
    /// @brief Replace a node with a new node at the given coordinate
    void replace_node(const coord& old_coord,  const coord& new_coord);
    void replace_node(const uint64_t& node_id, const coord& new_coord);

    virtual std::shared_ptr<Domain> clone() const override final { return std::make_shared<UnstructuredGrid>(*this); }

    template<typename ElementTypeName>
    typename std::set<ElementTypeName>::iterator begin() 
    {
        static_assert(std::is_base_of<Element, ElementTypeName>::value, "ElementTypeName must be a derived class of Element");
        if  (std::is_same<ElementTypeName, Node>::value) return m_nodes.begin();
        else if  (std::is_same<ElementTypeName, Edge>::value) return m_edges.begin();
        else if  (std::is_same<ElementTypeName, Triangle>::value) return m_triangles.begin();
        else if  (std::is_same<ElementTypeName, Quad>::value) return m_quads.begin();
        else if  (std::is_same<ElementTypeName, Tetrahedron>::value) return m_tetrahedrons.begin();
        else if  (std::is_same<ElementTypeName, Pyramid>::value) return m_pyramids.begin();
        else if  (std::is_same<ElementTypeName, Hexahedron>::value) return m_hexahedrons.begin();
        else assert(false && "Unknown Element Type");
    }

    template<typename ElementTypeName>
    typename std::set<ElementTypeName>::iterator end() 
    {
        static_assert(std::is_base_of<Element, ElementTypeName>::value, "ElementTypeName must be a derived class of Element");
        if  (std::is_same<ElementTypeName, Node>::value) return m_nodes.end();
        else if  (std::is_same<ElementTypeName, Edge>::value) return m_edges.end();
        else if  (std::is_same<ElementTypeName, Triangle>::value) return m_triangles.end();
        else if  (std::is_same<ElementTypeName, Quad>::value) return m_quads.end();
        else if  (std::is_same<ElementTypeName, Tetrahedron>::value) return m_tetrahedrons.end();
        else if  (std::is_same<ElementTypeName, Pyramid>::value) return m_pyramids.end();
        else if  (std::is_same<ElementTypeName, Hexahedron>::value) return m_hexahedrons.end();
        else assert(false && "Unknown Element Type");
    }

    std::vector<float>    get_float_coords() const;
    std::vector<uint32_t> get_edges() const;
    std::vector<uint32_t> get_all_trias() const;

    private:
    const uint64_t m_grid_id;
    std::string    m_grid_name;
        
    // Points
    std::set<Node> m_nodes;
    
    // Curves
    std::set<Edge> m_edges;

    // Polygons
    std::set<Triangle> m_triangles;
    std::set<Quad>     m_quads;

    // Volumes
    std::set<Tetrahedron> m_tetrahedrons;
    std::set<Pyramid>     m_pyramids;
    std::set<Hexahedron>  m_hexahedrons;

    // Element Id Maps
    std::vector<NodeIter>        m_node_id_map;
    std::vector<EdgeIter>        m_edge_id_map;
    std::vector<TriangleIter>    m_triangle_id_map;
    std::vector<QuadIter>        m_quad_id_map;
    std::vector<TetrahedronIter> m_tetrahedron_id_map;
    std::vector<PyramidIter>     m_pyramid_id_map;
    std::vector<HexahedronIter>  m_hexahedron_id_map;

    // Element Pointers
    std::vector<const Element*> m_elements;

    // Grid Id Management Utility
    static uint64_t get_unique_grid_id() { static uint64_t id = 0; return id++; }

    // Element Id Management Utilities
    struct id_type
    {
        id_type() : id(0) {}
        uint64_t id;
    };

    id_type node_id ;
    id_type edge_id ;
    id_type triangle_id ;
    id_type quad_id ;
    id_type tetrahedron_id ;
    id_type pyramid_id ;
    id_type hexahedron_id;
    
    template<typename ElementTypeName>
    uint64_t get_next_id()  
    {
        static_assert(std::is_base_of<Element, ElementTypeName>::value, "TypeName must be a derived class of Element");
        if  (std::is_same<ElementTypeName, Node>::value) return (node_id.id++);
        else if  (std::is_same<ElementTypeName, Edge>::value) return (edge_id.id++);
        else if  (std::is_same<ElementTypeName, Triangle>::value) return (triangle_id.id++);
        else if  (std::is_same<ElementTypeName, Quad>::value) return (quad_id.id++);
        else if  (std::is_same<ElementTypeName, Tetrahedron>::value) return (tetrahedron_id.id++);
        else if  (std::is_same<ElementTypeName, Pyramid>::value) return (pyramid_id.id++);
        else if  (std::is_same<ElementTypeName, Hexahedron>::value) return (hexahedron_id.id++);
        else assert(false && "get_next_id() called on Unknown Element Type");
    }

    // Prohibited way of modifying node (For Internal Use Only)
    NodeIter assign_node(const coord& in_coord, const uint64_t& id);

    // Prohibited way of modifying edge (For Internal Use Only)
    EdgeIter assign_edge(const Node* in_node1, const Node* in_node2, const uint64_t& id);

}; // Class UnstructuredGrid


template <typename T>
struct is_point_type : std::false_type {};

template <typename T>
struct is_curve_type : std::false_type {};

template <typename T>
struct is_polygon_type : std::false_type {};

template <typename T>
struct is_volume_type : std::false_type {};

template <>
struct is_point_type<UnstructuredGrid::Node> : std::true_type {};

template <>
struct is_curve_type<UnstructuredGrid::Edge> : std::true_type {};

template <>
struct is_polygon_type<UnstructuredGrid::Triangle> : std::true_type {};

template <>
struct is_polygon_type<UnstructuredGrid::Quad> : std::true_type {};

template <>
struct is_volume_type<UnstructuredGrid::Tetrahedron> : std::true_type {};

template <>
struct is_volume_type<UnstructuredGrid::Pyramid> : std::true_type {};

template <>
struct is_volume_type<UnstructuredGrid::Hexahedron> : std::true_type {};

#endif // GP_UNSTRUCTUREDGRID_HPP
