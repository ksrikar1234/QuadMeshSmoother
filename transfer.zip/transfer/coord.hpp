#ifndef ONED_CURVE_COORD_HPP
#define ONED_CURVE_COORD_HPP
#include "vec.h"
#include "../forwards/gp_forward_enums.h"
#include <cmath>
#include <cstddef>
#ifdef GP_GPU_PARALLEL
#include<openacc.h>
#endif

extern bool get_inverse_rotation_matrix(const double * rotation_matrix, double * inv_rotation_matrix);

/** \ingroup HalfEdgeModule
 * \class coord
 *
 * @brief Used for storing coordinates of a point in 3D space.
 */
class coord
{
public:
  /** @brief xyz coordinates */
  double x,y,z;
  /** @brief Constructor that takes 3 real values and set the xyz coordinates */
#ifdef GP_GPU_PARALLEL
#pragma acc routine 
#endif
  coord(double _x=0,double _y=0,double _z=0):x(_x),y(_y),z(_z)
  {} 
 
  /** @brief Constructor that takes an array of 3 elements and set the xyz coordinates */
  inline coord(const double * _c)
    : x(_c[0]), y(_c[1]), z(_c[2])
  {}
  /** @brief Assignment operator. Set the xyz coordinates to that of the input coord. */
  inline void operator=(const coord& a)
  {
    x=a.x,y=a.y,z=a.z;
  }

  inline bool operator==(const coord& a) const
  {
    return (x == a.x && y == a.y && z == a.z);
  }

  inline bool operator!=(const coord& a) const
  {
    return (x != a.x || y != a.y || z != a.z);
  }

  inline bool operator>(const coord& a) const
  {
    return (a < *this);
  }

  /** @brief Addition operator.  \f$c_1 = c_2 + c_3\f$ */
  inline coord operator+(const coord& a) const
  {
    return coord(x+a.x,y+a.y,z+a.z);
  }

  /** @brief Subtraction operator.  \f$c_1 = c_2 - c_3\f$ */
  inline coord operator-(const coord& a) const
  {
    return coord(x-a.x,y-a.y,z-a.z);
  }
 
  /** @brief Inplace subtraction. \f$c_1 -= c_2 \f$ */
  inline void operator-=(const coord& a)
  {
    x-=a.x,y-=a.y,z-=a.z;
  }

  /** @brief Inplace addition. \f$c_1 += c_2 \f$ */
  inline void operator+=(const coord& a)
  {
    x+=a.x,y+=a.y,z+=a.z;
  }

  /** @brief Scalar multiplication. \f$c_1 = c_2*scalar\f$ */
  inline coord operator*(double a) const
  { 
    return coord(x*a,y*a,z*a);
  }

  /** @brief Scalar division. \f$c_1 = c_2/scalar\f$ */
  inline coord operator/(double a) const
  {
    double d = (1/a);
    return coord(x*d,y*d,z*d);
  }

  /** @brief Inplace scalar multiplication. \f$c_1 *= scalar \f$ */
  inline void operator*=(double a)
  {
    x*=a,y*=a,z*=a;
  }
  
  /** @brief Cross product of two coords. \f$c_1 = c_2*c_3 \f$ */
  inline coord operator*(const coord& a) const
  {
      double X,Y,Z;
      X = y*a.z-a.y*z;
      Y = z*a.x-a.z*x;
      Z = x*a.y-a.x*y;
      return coord(X,Y,Z);
  }
  
  /** @brief Inplace scalar division. \f$c_1 /= scalar \f$ */
  inline void operator /=(double a)
  {
    double d= 1/a;
    x*=d,y*=d,z*=d;
  }

  /** @brief Inplace addition using a \ref vec "vec". \f$c_1 += v \f$ */  
    inline void operator +=(const ::vec& a)
  {
    x+=a.nx,y+=a.ny,z+=a.nz;
  }

  /** @brief Inplace subtraction using a \ref vec "vec". \f$c_1 -= v \f$ */  
    inline void operator -=(const ::vec& a)
  {
    x-=a.nx,y-=a.ny,z-=a.nz;
  }
  
  /** @brief Addition of  \ref vec "vec" to this coord. \f$c_1 = c_2 + v \f$ */  
    inline coord operator+(const ::vec& a) const
  {
    return coord(x+a.nx,y+a.ny,z+a.nz);
  }
  /** @brief Subtraction of  \ref vec "vec" from this coord. \f$c_1 = c_2 - v \f$ */  
    inline coord operator-(const ::vec& a) const
  {
    return coord(x-a.nx,y-a.ny,z-a.nz);
  }
  /** @brief dot product of two coords. \f$ c_1.c_2 \f$*/
  inline double dot(const coord& a) const
  {
    return x*a.x+y*a.y+z*a.z;
  }
  /** @brief Magnitude of the coord. \f$ |c| \f$ */
  inline double abs() const
  {
    return std::sqrt(x*x+y*y+z*z);
  }
    bool is_null() const
    {
	return (abs() < topology_defns::error_margin2);
    }
  /** @brief Normalize the coord. \f$ \hat{c} = \frac{c}{|c|} \f$ */
  inline double normalize()
  {
      double r=abs();
      if(r > 1e-6)
      {
	  x/=r;
	  y/=r;
	  z/=r;
      }
      return r;
  }
  /** @brief Get the unit vector aligned to the coord. \f$ \hat{c} = \frac{c}{|c|} \f$ */
  inline coord unit_vector() const
  {
      coord uvec = *this;
      uvec.normalize();
      return uvec;
  }
  /** @brief Get the square of the magnitude. \f$ |c|^2 \f$ */
  inline double magnitude_sqr() const
  {
      return x*x+y*y+z*z;
  }
  /** @brief Dot product of a coord and a \ref vec "vec". */
    inline double dot(const ::vec& a) const
  {
    return x*a.nx+y*a.ny+z*a.nz;
  }
  /** @brief Get a component of the coord. */  
  inline double & operator[](const unsigned short & index)
  {
      switch(index)
      { 
	case 0:	  return x;
	case 1:	  return y;
	case 2:	  return z;
      }
      return x;
  }
  inline const double & operator[](const unsigned short & index) const
  {
      switch(index)
      { 
	case 0:	  return x;
	case 1:	  return y;
	case 2:	  return z;
      }
      return x;
  }
    inline void set_component(const unsigned short & index, const double & d)
	{
	    switch(index)
	    { 
		case 0:	  x = d; break;
		case 1:	  y = d; break;
		case 2:	  z = d; break;
	    }
	    
	}
    bool operator<(const coord & another_vec) const
    { 
      if(x < another_vec.x) return true;
      else if(x > another_vec.x) return false;
      else 
      {
          if(y < another_vec.y) return true;    
          else if(y > another_vec.y) return false;
          else
          {
              if(z < another_vec.z) return true;
              else return false;
          }
      }
    }
    
  /** @brief Transformation of the coord using rotation matrix and translation vector. */
  void transform(const double * rotation_matrix, const double * translation_matrix)
  {
  //printf("transform() called by gang: %d, worker: %d, vector: %d\n",__pgi_gangidx(),__pgi_workeridx(),__pgi_vectoridx());
      if(rotation_matrix)
      {
	  double init_coords[3] = { x, y, z };
	  x = rotation_matrix[0]*init_coords[0] + rotation_matrix[1]*init_coords[1] + rotation_matrix[2]*init_coords[2];
	  y = rotation_matrix[3]*init_coords[0] + rotation_matrix[4]*init_coords[1] + rotation_matrix[5]*init_coords[2];
	  z = rotation_matrix[6]*init_coords[0] + rotation_matrix[7]*init_coords[1] + rotation_matrix[8]*init_coords[2];
      }
      if(translation_matrix)
      {
	  x += translation_matrix[0];
	  y += translation_matrix[1];
	  z += translation_matrix[2];
      }
  }

  /** @brief Inverse transformation of the coord using rotation matrix and translation vector. */  
  void inverse_transform(const double * rotation_matrix, const double * translation_matrix)
  {
      if(translation_matrix)
      {
	  x -= translation_matrix[0];
	  y -= translation_matrix[1];
	  z -= translation_matrix[2];
      }

      if(rotation_matrix)
      {
	  double inv_rotation_matrix[9];
	  if(get_inverse_rotation_matrix(rotation_matrix, inv_rotation_matrix))
	      transform(inv_rotation_matrix, NULL);
	  else
	  {
	      double determinant =
		  rotation_matrix[0]*(rotation_matrix[4]*rotation_matrix[8] - rotation_matrix[5]*rotation_matrix[7]) +
		  rotation_matrix[1]*(rotation_matrix[5]*rotation_matrix[6] - rotation_matrix[3]*rotation_matrix[8]) +
		  rotation_matrix[2]*(rotation_matrix[3]*rotation_matrix[7] - rotation_matrix[4]*rotation_matrix[6]);
	      double scaling_factor = 1./determinant;
	      double new_rotation_matrix[9] = {scaling_factor, 0., 0., 0., scaling_factor, 0., 0., 0., scaling_factor};
	      transform(new_rotation_matrix, NULL);
	      for(unsigned short index = 0; index < 9; ++index)
		  new_rotation_matrix[index] = rotation_matrix[index]*scaling_factor;
	      if(get_inverse_rotation_matrix(new_rotation_matrix, inv_rotation_matrix))
		  transform(inv_rotation_matrix, NULL);
	  }
      }
  }

    const double * get_vector() const
    { return &x; }

    const coord & Pos() const
    { return *this; }


    double distance_to(const coord& other) const 
    {
      return std::sqrt(std::pow(x - other.x, 2) + 
                       std::pow(y - other.y, 2) + 
                       std::pow(z - other.z, 2));
    }

    double distance_squared(const coord& other) const 
    {
      return std::pow(x - other.x, 2) + 
             std::pow(y - other.y, 2) + 
             std::pow(z - other.z, 2);
    }
};

#endif
