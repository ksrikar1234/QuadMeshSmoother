#include "grid_headers/unstructured/OpenFoamPolyMesh.hpp"

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <algorithm>
#include <cstdint>
#include "common_headers/common/coord.hpp"
#include "common_headers/common/gp_std_lib/gp_filestream.hpp"

// Constructor
OpenFoamPolyMeshAdaptor::OpenFoamPolyMeshAdaptor() {}

// Load all mesh files
bool OpenFoamPolyMeshAdaptor::loadFromPolyMesh(const std::string &meshDir)
{
    return readPoints(meshDir + "/points") &&
           readFaces(meshDir + "/faces") &&
           readOwnerNeighbour(meshDir + "/owner", meshDir + "/neighbour") &&
           readBoundary(meshDir + "/boundary") &&
           readFaceZones(meshDir + "/faceZones") &&
           readCellZones(meshDir + "/cellZones");
}

// Print basic info about the mesh
void OpenFoamPolyMeshAdaptor::printMeshInfo() const
{
    std::cout << "OpenFOAM Mesh Info:\n";
    std::cout << "  Points: " << points.size() << "\n";
    std::cout << "  Faces: " << faces.size() << "\n";
    std::cout << "  Cells: " << cells.size() << "\n";
    std::cout << "  Boundaries: " << boundaries.size() << "\n";
}

// Read point coordinates from file
bool OpenFoamPolyMeshAdaptor::readPoints(const std::string &filePath)
{   
    printf("Reading Points from %s\n", filePath.c_str());

    std::ifstream file(filePath);
    if (!file)
    {
        std::cerr << "Cannot open points file: " << filePath << "\n";
        return false;
    }

    std::string line, prev_line;
    while (std::getline(file, line))
    {
        if (line == "(")
            break;
        prev_line = line;
    }
    
    uint32_t numPoints = 0;
    std::istringstream iss(prev_line);
    iss >> numPoints;
    points.resize(numPoints);

    printf("Number of Points : %d\n", numPoints);
    
    auto read_coord = [](std::string& line, coord& c)
    {
        std::replace(line.begin(), line.end(), '(', ' ');
        std::replace(line.begin(), line.end(), ')', ' ');
        
        std::istringstream iss(line);
        iss >> c.x >> c.y >> c.z;
    };

    uint32_t index = 0;
    while(std::getline(file, line))
    {
        if(index >= numPoints)
        {
            if (line == ")") break;
            std::cerr << "Too many points in file: " << filePath << std::endl;
            return false;
        }

        read_coord(line, points[index++]);
    }
    printf("Read %d points\n", numPoints);
    return true;
}

// Read faces from file
bool OpenFoamPolyMeshAdaptor::readFaces(const std::string &filePath)
{
    printf("Reading Faces from %s\n", filePath.c_str());

    std::ifstream file(filePath);
    if (!file)
    {
        std::cerr << "Cannot open faces file: " << filePath << "\n";
        return false;
    }

    uint32_t numFaces = 0;  

    std::string line, prev_line;
    while (std::getline(file, line))
    {
        if (line == "(")
            break;
        prev_line = line;
    }

    std::istringstream iss(prev_line);
    iss >> numFaces;
    faces.resize(numFaces);

    printf("Number of Faces : %d\n", numFaces);
    
    auto read_face = [](std::string& line, Face& f) -> void
    {
        std::replace(line.begin(), line.end(), '(', ' ');
        std::replace(line.begin(), line.end(), ')', ' ');
        
        std::istringstream iss(line);
        uint32_t nPts = 0;
        iss >> nPts; // number of points in this face
        f.nodeIndices.resize(nPts);
        for (uint32_t j = 0; j < nPts; j++)
        {
            iss >> f.nodeIndices[j];
        }
    };
    
    uint32_t index = 0;

    while(std::getline(file, line))
    {
        if(index >= numFaces)
        {
            if (line == ")") break;
            std::cerr << "Too many faces in file: " << filePath << std::endl;
            return false;
        }
       read_face(line, faces[index++]);
    }
   
    printf("Read %d faces\n", numFaces);
    return true;
}

// Read owner & neighbour data
bool OpenFoamPolyMeshAdaptor::readOwnerNeighbour(const std::string &ownerPath, const std::string &neighbourPath)
{  
    printf("Reading Owner and Neighbour Data\n");
    std::ifstream ownerFile(ownerPath);
    std::ifstream neighbourFile(neighbourPath);
    
    if (!ownerFile)
    {
        std::cerr << "Cannot open owner file: " << ownerPath << "\n";
        return false;
    }
    
    if (!neighbourFile)
    {
        std::cerr << "Cannot open neighbour file: " << neighbourPath << "\n";
        return false;
    }

    // Reading owner data
    {
        std::string line, prev_line;
        while(std::getline(ownerFile, line))
        {
            if (line == "(")
                break;
            prev_line = line;
        }

        uint32_t numCells = 0;
        std::istringstream iss(prev_line);
        iss >> numCells;
        
        cells.resize(numCells);

        uint32_t CellIndex = 0; // Index of the cell

        while(std::getline(ownerFile, line))
        {
            if (CellIndex >= numCells)
            {
                if (line == ")") break;
                std::cerr << "Too many cells in owner file: " << ownerPath << std::endl;
                return false;
            }

            std::istringstream iss(line);
            uint32_t FaceIndex = 0;
            iss >> FaceIndex; // Face it owns
            cells[CellIndex].owningFaces.push_back(FaceIndex);
        }
    }

    {
        // Reading neighbour data
        std::string line, prev_line;
        while(std::getline(neighbourFile, line))
        {
            if (line == "(") break;
            prev_line = line;
        }

        uint32_t numInternalFaces = 0;
        std::istringstream iss(prev_line);
        iss >> numInternalFaces;
        printf("Number of Internal Faces : %d\n", numInternalFaces);
        
        // We assume faces has already been sized to numFaces in readFaces()
        uint32_t FaceIndex = 0;
        while(std::getline(neighbourFile, line))
        {
            if (FaceIndex >= numInternalFaces)
            {
                if (line == ")") break;
                std::cerr << "Too many faces in neighbour file: " << neighbourPath << std::endl;
                return false;
            }

            std::istringstream iss(line);
            iss >> faces[FaceIndex++].neighbour;
        }        
    }
    printf("Read Owner and Neighbour Data\n");
    return true;
}

// Read boundary information
bool OpenFoamPolyMeshAdaptor::readBoundary(const std::string& boundaryPath)
{
    printf("Reading Boundary Data\n");

    gp_std::file_stream file(boundaryPath);
    if(!file)
    {
        std::cerr << "Cannot open boundary file: " << boundaryPath << "\n";
        return false;
    }

    auto iter = file.match_str("(");

    if(iter)
    {
        uint32_t numBoundaries = 0;
        std::istringstream iss(*(--iter));  ++iter;
        iss >> numBoundaries;
        boundaries.resize(numBoundaries);

        printf("Number of Boundaries : %d\n", numBoundaries);

        uint32_t currBoundary = 0;
        
        while(iter)
        {
            iter = file.find_str("{", iter);
            if(iter)
            {
                std::istringstream iss(*(--iter));
                iss >> boundaries[currBoundary].name;
                
                std::cout << "Boundary Name: " << boundaries[currBoundary].name << "\n";

                iter = file.find_str("type", iter);

                if(iter)
                {
                    std::istringstream iss1(*iter);
                    std::string type;
                    iss1 >> type;
                    iss1 >> boundaries[currBoundary].type ;
                    std::cout << "Boundary Type: " << boundaries[currBoundary].type << "\n";
                }

                iter = file.find_str("nFaces", iter);

                if(iter)
                {
                    std::istringstream iss2(*iter);
                    std::string nFaces;
                    iss2 >> nFaces;
                    iss2 >> boundaries[currBoundary].numFaces;
                    std::cout << "Number of Faces: " << boundaries[currBoundary].numFaces << "\n";
                }

                iter = file.find_str("startFace", iter);

                if(iter)
                {
                    std::istringstream iss3(*iter);
                    std::string startFace;
                    iss3 >> startFace;
                    iss3 >> boundaries[currBoundary].startFace;
                    std::cout << "Start Face: " << boundaries[currBoundary].startFace << "\n";
                }

                ++currBoundary;
            }
        }
    }

    printf("Read Boundary Data\n");
    return true;
}


bool OpenFoamPolyMeshAdaptor::readFaceZones(const std::string& faceZonesPath)
{
    printf("Reading Face Zones\n");
   
    gp_std::file_stream file(faceZonesPath);

    if (!file)
    {
        std::cerr << "Cannot open face zones file: " << faceZonesPath << "\n";
        return false;
    }

    auto iter = file.match_str("(");

    if(iter)
    {
        uint32_t numFaceZones = 0;
        std::istringstream iss(*(--iter));  ++iter;
        iss >> numFaceZones;
        faceZones.resize(numFaceZones);

        printf("Number of Face Zones : %d\n", numFaceZones);

        uint32_t currFaceZone = 0;
        
        while(iter)
        {
            iter = file.find_str("{", iter);
            if(iter)
            {
                std::istringstream iss(*(--iter));
                iss >> faceZones[currFaceZone].name;

                std::cout << "Face Zone Name: " << faceZones[currFaceZone].name << "\n";

                iter = file.match_str("(", iter);

                if(iter)
                {
                    std::istringstream iss1(*(--iter));
                    uint32_t numFaces = 0;
                    iss1 >> numFaces;
                    faceZones[currFaceZone].faceIndices.resize(numFaces);
                    
                    std::cout << "Number of Faces: " << numFaces << "\n";

                    uint32_t currFaceIndex = 0;
                    iter += 2;

                    while(*iter != ")" && iter)
                    {
                        std::istringstream iss2(*iter);
                        iss2 >> faceZones[currFaceZone].faceIndices[currFaceIndex++];
                        ++iter;
                    }
                }

                ++currFaceZone;
                if(currFaceZone == numFaceZones)
                {
                    break;
                }
            }
        }
    }
     
    printf("Successfully read face zones\n");
    return true;
}


bool OpenFoamPolyMeshAdaptor::readCellZones(const std::string& cellZonesPath)
{
    printf("Reading Cell Sets\n");
   
    gp_std::file_stream file(cellZonesPath);

    if (!file)
    {
        std::cerr << "Cannot open cell zones file: " << cellZonesPath << "\n";
        return false;
    }

    auto iter = file.match_str("(");

    if(iter)
    {
        uint32_t numCellZones = 0;
        std::istringstream iss(*(--iter));  ++iter;
        iss >> numCellZones;
        cellZones.resize(numCellZones);

        printf("Number of Cell Zones : %d\n", numCellZones);

        uint32_t currCellZone = 0;
        
        while(iter)
        {
            iter = file.find_str("{", iter);
            if(iter)
            {
                std::istringstream iss(*(--iter));
                iss >> cellZones[currCellZone].name;

                iter = file.match_str("(", iter);

                if(iter)
                {
                    std::istringstream iss1(*(--iter));
                    uint32_t numCells = 0;
                    iss1 >> numCells;
                    cellZones[currCellZone].cellIndices.resize(numCells);
                    
                    std::cout << "Number of Cells: " << numCells << "\n";

                    uint32_t currCellIndex = 0;
                    iter += 2;

                    while(*iter != ")" && iter)
                    {
                        std::istringstream iss2(*iter);
                        iss2 >> cellZones[currCellZone].cellIndices[currCellIndex++];
                        ++iter;
                    }
                }

                ++currCellZone;

                if(currCellZone == numCellZones)
                {
                    break;
                }
            }
        }
    }

    printf("Read Cell Zones\n");
    return true;
}


std::vector<float> OpenFoamPolyMeshAdaptor::get_nodes() const
{
    std::vector<float> nodes(points.size()*3);
    uint32_t i = 0;
    for (const coord& c : points)
    {
        nodes[i] = c.x;
        nodes[i + 1] = c.y;
        nodes[i + 2] = c.z;
        i += 3;
    }
    return nodes;
}

std::vector<uint32_t> OpenFoamPolyMeshAdaptor::get_faces_as_trias() const
{
    std::vector<uint32_t> trias;

    uint32_t total_number_of_trias = 0; 

    for(const Face& f : faces)
    {
        if(f.nodeIndices.size() == 3)
        {
            total_number_of_trias += 1;
        }
        else if(f.nodeIndices.size() == 4)
        {
            total_number_of_trias += 2;
        }
        else if(f.nodeIndices.size() > 4)
        {
            total_number_of_trias += f.nodeIndices.size() - 2;
        }
    }

    trias.resize(total_number_of_trias*3);

    auto it = trias.begin();

    for (const Face& f : faces)
    {
        if(f.nodeIndices.size() == 3)
        {
            *(it++) = f.nodeIndices[0];
            *(it++) = f.nodeIndices[1];
            *(it++) = f.nodeIndices[2];
        }
        else if(f.nodeIndices.size() == 4)
        {
            *(it++) = f.nodeIndices[0];
            *(it++) = f.nodeIndices[1];
            *(it++) = f.nodeIndices[2];
            *(it++) = f.nodeIndices[0];
            *(it++) = f.nodeIndices[2];
            *(it++) = f.nodeIndices[3];
        }
        else if(f.nodeIndices.size() > 4)
        {
            for(uint32_t i = 1; i < f.nodeIndices.size() - 1; ++i)
            {
                *(it++) = f.nodeIndices[0];
                *(it++) = f.nodeIndices[i];
                *(it++) = f.nodeIndices[i + 1];
            }
        }
    }

    return trias;
}

std::vector<uint32_t> OpenFoamPolyMeshAdaptor::get_edges_of_all_faces() const
{
    std::vector<uint32_t> edges;

    uint32_t total_number_of_edges = 0;

    for(const Face& f : faces)
    {
        total_number_of_edges += f.nodeIndices.size();
    }

    edges.resize(total_number_of_edges*2);

    auto it = edges.begin();

    for(const Face& f : faces)
    {
        for(uint32_t i = 0; i < f.nodeIndices.size(); ++i)
        {
            *(it++) = f.nodeIndices[i];
            *(it++) = f.nodeIndices[(i + 1) % f.nodeIndices.size()];
        }
    }

    return edges;
}