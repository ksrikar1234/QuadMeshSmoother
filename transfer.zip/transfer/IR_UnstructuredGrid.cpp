#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <iomanip>

#include <cstdlib>
#include <cstring>

#include "grid_headers/unstructured/IR_UnstructuredGrid.hpp"
#include "grid_headers/common_components/Octree.hpp"


IR_UnstructuredGrid::IR_UnstructuredGrid(const char* in_file_name) : Generic::Domain(Generic::Domain::Unstructured) 
{
    load_gmsh(in_file_name);
}

IR_UnstructuredGrid::IR_UnstructuredGrid(const IR_UnstructuredGrid& in)  : Generic::Domain(Generic::Domain::Unstructured) 
{
    m_coords = in.m_coords; m_nodes = in.m_nodes;
    m_edges = in.m_edges;   m_triangles = in.m_triangles;
    m_quads = in.m_quads;   m_tetrahedrons = in.m_tetrahedrons;
    m_hexahedrons = in.m_hexahedrons; m_pyramids = in.m_pyramids;
    m_prisms = in.m_prisms; m_grid_id = in.m_grid_id;
    m_grid_name = in.m_grid_name;
}

IR_UnstructuredGrid::IR_UnstructuredGrid(IR_UnstructuredGrid&& in) : Generic::Domain(Generic::Domain::Unstructured) 
{
    m_coords = std::move(in.m_coords); m_nodes = std::move(in.m_nodes);
    m_edges = std::move(in.m_edges);   m_triangles = std::move(in.m_triangles);
    m_quads = std::move(in.m_quads);   m_tetrahedrons = std::move(in.m_tetrahedrons);
    m_hexahedrons = std::move(in.m_hexahedrons); m_pyramids = std::move(in.m_pyramids);
    m_prisms = std::move(in.m_prisms);
    m_grid_id = std::move(in.m_grid_id); m_grid_name = std::move(in.m_grid_name);
}

IR_UnstructuredGrid& IR_UnstructuredGrid::operator=(const IR_UnstructuredGrid& in)
{
    m_coords = in.m_coords; m_nodes = in.m_nodes;
    m_edges = in.m_edges;   m_triangles = in.m_triangles;
    m_quads = in.m_quads;   m_tetrahedrons = in.m_tetrahedrons;
    m_hexahedrons = in.m_hexahedrons; m_pyramids = in.m_pyramids;
    m_prisms = in.m_prisms; m_grid_id = in.m_grid_id;
    m_grid_name = in.m_grid_name;
    return *this;
}

IR_UnstructuredGrid& IR_UnstructuredGrid::operator=(IR_UnstructuredGrid&& in)
{
    m_coords = std::move(in.m_coords);
    m_nodes = std::move(in.m_nodes);
    m_edges = std::move(in.m_edges);
    m_triangles = std::move(in.m_triangles);
    m_quads = std::move(in.m_quads);
    m_tetrahedrons = std::move(in.m_tetrahedrons);
    m_hexahedrons = std::move(in.m_hexahedrons);
    m_pyramids = std::move(in.m_pyramids);
    m_prisms = std::move(in.m_prisms);
    m_grid_id = std::move(in.m_grid_id);
    m_grid_name = std::move(in.m_grid_name);
    return *this;
}

// File IO
bool IR_UnstructuredGrid::load_gmsh(const char* in_file_name)
{
    std::ifstream file(in_file_name);
    if (!file.is_open())
    {
        std::cerr << "Error: Could not open file " << in_file_name << std::endl;
        return false;
    }

    std::string line;

    // Jump to $Nodes section
    while (std::getline(file, line))
    {
        if (line.find("$Nodes") != std::string::npos)
        {
            break;
        }
    }

    // Read the number of nodes
    uint64_t num_nodes;
    file >> num_nodes;
    if (!file)
    {
        std::cerr << "Error: Could not read the number of nodes." << std::endl;
        return false;
    }
    m_coords.resize(num_nodes);

    // Read the nodes
    for (uint64_t i = 0; i < num_nodes; ++i)
    {
        uint64_t id;
        double x, y, z;
        file >> id >> x >> y >> z;
        if (!file)
        {
            std::cerr << "Error: Could not read node data." << std::endl;
            return false;
        }
        m_coords[id-1].x = x; 
        m_coords[id-1].y = y;
        m_coords[id-1].z = z;
    }

    // Jump to $Elements section
    while (std::getline(file, line))
    {
        if (line.find("$Elements") != std::string::npos)
        {
            break;
        }
    }

    // Read the number of elements
    uint64_t num_elements;
    file >> num_elements;
    
    if (!file)
    {
        std::cerr << "Error: Could not read the number of elements." << std::endl;
        return false;
    }

    // Read the elements
    for (uint64_t i = 0; i < num_elements; ++i)
    {
        uint64_t id, type, num_tags;
        file >> id >> type >> num_tags;
        if (!file)
        {
            std::cerr << "Error: Could not read element header." << std::endl;
            return false;
        }

        // Skip the tags (physical and elementary entities)  
        for (uint64_t j = 0; j < num_tags; ++j)
        {
            uint64_t tag;
            file >> tag;
        }
        
        switch (type)
        {
            case 1:  // 2-node line
            {
                uint64_t node1, node2;
                file >> node1 >> node2;
                m_edges.emplace_back(this, node1 - 1, node2 - 1);  // Using emplace_back to directly construct
                break;
            }

            case 2:  // 3-node triangle
            {
                uint64_t node1, node2, node3;
                file >> node1 >> node2 >> node3;
                m_triangles.emplace_back(this, node1 - 1, node2 - 1, node3 - 1);  // Using emplace_back to directly construct
                break;
            }
            case 3:  // 4-node quadrilateral
            {
                uint64_t node1, node2, node3, node4;
                file >> node1 >> node2 >> node3 >> node4;
                m_quads.emplace_back(this,node1 - 1, node2 - 1, node3 - 1, node4 - 1);  // Using emplace_back to directly construct
                break;
            }
            case 4:  // 4-node tetrahedron
            {
                uint64_t node1, node2, node3, node4;
                file >> node1 >> node2 >> node3 >> node4;
                m_tetrahedrons.emplace_back(this,node1 - 1, node2 - 1, node3 - 1, node4 - 1);  // Using emplace_back
                break;
            }
            case 5:  // 8-node hexahedron
            {
                uint64_t node1, node2, node3, node4, node5, node6, node7, node8;
                file >> node1 >> node2 >> node3 >> node4 >> node5 >> node6 >> node7 >> node8;
                m_hexahedrons.emplace_back(this,node1 - 1, node2 - 1, node3 - 1, node4 - 1, 
                                           node5 - 1, node6 - 1, node7 - 1, node8 - 1);  // Using emplace_back
                break;
            }
            
            case 6: // 6-node prism
            {
                uint64_t node1, node2, node3, node4, node5, node6;
                file >> node1 >> node2 >> node3 >> node4 >> node5 >> node6;
                m_prisms.emplace_back(this,node1 - 1, node2 - 1, node3 - 1, node4 - 1, 
                                      node5 - 1, node6 - 1);  // Using emplace_back
                break;
            }

            case 15:  // 1-node point
            {
                uint64_t node1;
                file >> node1;
                m_nodes.emplace_back(this,node1 - 1);  // Using emplace_back
                break;
            }

            // Handle other element types like second-order elements here
            default:
                //std::cerr << "Warning: Unsupported element type " << type << std::endl;
                break;
        }
    }

    return true;
}

bool IR_UnstructuredGrid::load_openfoam(const char* in_polymesh_folder_name)
{
  std::string node_file_name = std::string(in_polymesh_folder_name) + "/points";
  std::string face_file_name = std::string(in_polymesh_folder_name) + "/faces";
  std::string owner_file_name = std::string(in_polymesh_folder_name) + "/owner";
  std::string neighbour_file_name = std::string(in_polymesh_folder_name) + "/neighbour";
  
  // Binary mode
  std::ifstream node_file(node_file_name, std::ios::binary);
  if(!node_file.is_open())
  {
    std::cerr << "Error: Could not open file " << node_file_name << std::endl;
    return false;
  }

  std::ifstream face_file(face_file_name, std::ios::binary);

  if(!face_file.is_open())
  {
    std::cerr << "Error: Could not open file " << face_file_name << std::endl;
    return false;
  }

  std::ifstream owner_file(owner_file_name, std::ios::binary);
    
  if(!owner_file.is_open())
  {
    std::cerr << "Error: Could not open file " << owner_file_name << std::endl;
    return false;
  }

  std::ifstream neighbour_file(neighbour_file_name, std::ios::binary);

  if(!neighbour_file.is_open())
  {
    std::cerr << "Error: Could not open file " << neighbour_file_name << std::endl;
    return false;
  }
    
  bool is_binary = false;


  // Read the nodes 
  std::string line, prev_line;
  std::size_t bracket_pos;
  while(std::getline(node_file, line))
  {
    //std::cout << "Line: " << line << std::endl;
    bracket_pos = line.find("(");
    if(line.find("ascii") != std::string::npos)
    {
        is_binary = false;
    }

    else if (line.find("binary") != std::string::npos)
    {
        is_binary = true;
    }

    if (bracket_pos != std::string::npos)
    {
            break;
    }
    prev_line = line;
  }

  uint64_t num_nodes;
  std::istringstream iss(prev_line);
  iss >> num_nodes;
  m_coords.resize(num_nodes);

  std::cout << "Number of Nodes: " << num_nodes << std::endl;
    
  if(is_binary)
  {  
    // remove everything upto bracket position
    std::string leftover = line.substr(bracket_pos+1);
    std::vector<char> raw_data(leftover.begin(), leftover.end());
    memcpy(m_coords.data(), raw_data.data(), m_coords.size()*sizeof(double)*3); 
  }
  else
  {
    for(uint64_t i = 0; i < num_nodes; i++)
    {
        std::string line;
        std::getline(node_file, line);
        //std::cout << "Line: " << line << std::endl;
        std::istringstream coord_stream(line);            
        char c;
        double x, y, z;
        coord_stream >> c >> x >> y >> z >> c;
        m_coords[i].x = x;
        m_coords[i].y = y;
        m_coords[i].z = z;
    }
  }

  //for(auto& coord : m_coords)
     //std::cout << coord.x << " " << coord.y << " " << coord.z << std::endl;
  
  // Read the faces
  bool is_binary_face = false;
  
  while(std::getline(face_file, line))
  {
    //std::cout << "Line Face: " << line << std::endl;
    bracket_pos = line.find("(");
    if(line.find("ascii") != std::string::npos)
    {
        is_binary_face = false;
    }

    else if (line.find("binary") != std::string::npos)
    {
        is_binary_face = true;
    }

    if (bracket_pos != std::string::npos)
    {
        break;
    }
    prev_line = line;
  }
  
  uint64_t num_faces;
  std::istringstream iss_face(prev_line);
  iss_face >> num_faces;
  
  std::cout << "Number of Faces: " << num_faces << std::endl;


  if(is_binary_face)
  {
    // unitil file end
    while(std::getline(face_file, line))
    {
      std::cout << "Line Face: " << line << std::endl;
      if(face_file.eof())
      {
        break;
      }
    }
  }
  else
  {
    std::cout << "Loading faces" << std::endl;
    for(uint64_t i = 0; i < num_faces; i++)
    {
        std::string line;
        std::getline(face_file, line);
        std::istringstream face_stream(line);
        //std::cout << "Line: " << line << std::endl;
        char c;
        int32_t num_nodes;
        face_stream >>  num_nodes >> c;
        if(num_nodes == 3)
        {
            int32_t n1, n2, n3;
            face_stream >> n1 >> n2 >> n3 >> c;
            //std::cout << "Triangle: " << n1 << " " << n2 << " " << n3 << std::endl;
            m_triangles.emplace_back(this, n1, n2, n3);
        }
        else if(num_nodes == 4)
        {
            int32_t n1, n2, n3, n4;
            face_stream >> n1 >> n2 >> n3 >> n4 >> c;
            //std::cout << "Quad: " << n1 << " " << n2 << " " << n3 << " " << n4 << std::endl;
            m_quads.emplace_back(this, n1, n2, n3, n4);
        }
    }
    std::cout << "Loaded faces" << std::endl;
  }

  return true;

}

// OpenGL Rendering Helpers
std::vector<float> IR_UnstructuredGrid::get_float_coords() 
{
    std::vector<float> float_coords(m_coords.size()*3);
    for(uint32_t i = 0; i < m_coords.size(); i++)
    {
        const uint32_t index = i*3;
        float_coords[index] = m_coords[i].x;
        float_coords[index + 1] = m_coords[i].y;
        float_coords[index + 2] = m_coords[i].z;
    }
    return float_coords;
}

std::vector<uint32_t> IR_UnstructuredGrid::get_all_quads() 
{
    std::vector<uint32_t> all_quads;
    for(const auto& quad : m_quads)
    {
        all_quads.push_back(quad.node_1);
        all_quads.push_back(quad.node_2);
        all_quads.push_back(quad.node_3);
        all_quads.push_back(quad.node_4);
    }
            
    for(const auto& pyramid : m_pyramids)
    {
        const auto& quad = pyramid.get_quad_face(0);  
        all_quads.push_back(quad[0]);
    }

    for(const auto& prism : m_prisms)
    {
        for(uint8_t i = 0; i < 3; i++)
        {
            const auto& quad = prism.get_quad_face(i);
            all_quads.push_back(quad[0]);
            all_quads.push_back(quad[1]);
            all_quads.push_back(quad[2]);
            all_quads.push_back(quad[3]);
        }
    }

    for(const auto& hexahedron : m_hexahedrons)
    {
        for(uint8_t i = 0; i < 6; i++)
        {
            const auto& quad = hexahedron.get_quad_face(i);
            all_quads.push_back(quad[0]);
            all_quads.push_back(quad[1]);
            all_quads.push_back(quad[2]);
            all_quads.push_back(quad[3]);
        }
    }
    return all_quads;
}


std::vector<uint32_t> IR_UnstructuredGrid::get_all_trias()  
{
    all_trias.clear();
    for(const auto& triangle : m_triangles)
    {
         all_trias.push_back(triangle.node_1);
         all_trias.push_back(triangle.node_2);
         all_trias.push_back(triangle.node_3);
    }
    
    std::cout  << "Num Tetrahedrons: " << m_tetrahedrons.size() << std::endl;

    for(const auto& tetrahedron : m_tetrahedrons)
    {
        for(uint8_t i = 0; i < 4; i++)
        {
            const auto& tria = tetrahedron.get_face(i);
            all_trias.push_back(tria[0]);
            all_trias.push_back(tria[1]);
            all_trias.push_back(tria[2]);
        }
    }

    for(const auto& pyramid : m_pyramids)
    {
        for(uint8_t i = 0; i < 4; i++)
        {
            const auto& tria = pyramid.get_tria_face(i);
            all_trias.push_back(tria[0]);
            all_trias.push_back(tria[1]);
            all_trias.push_back(tria[2]);
        }
    }
    return all_trias;

}

std::vector<float> IR_UnstructuredGrid::get_tria_normals()
{
    m_normals.resize(m_coords.size());

    std::vector<uint32_t>& indices = all_trias;
    // Iterate over all triangles
    for (uint32_t i = 0; i < indices.size(); i += 3) {
        // Get the indices of the triangle vertices
        uint32_t idx1 = indices[i];
        uint32_t idx2 = indices[i + 1];
        uint32_t idx3 = indices[i + 2];

        // Get the vertex positions for the triangle
        const coord& v1 = m_coords[idx1];
        const coord& v2 = m_coords[idx2];
        const coord& v3 = m_coords[idx3];

        // Calculate the two edges of the triangle
        coord edge1 = v2 - v1;
        coord edge2 = v3 - v1;

        // Compute the cross product of the edges to get the triangle's normal
        coord normal = edge1*edge2;

        // Add the triangle's normal to each of the vertices' normals
        m_normals[idx1] += normal;
        m_normals[idx2] += normal;
        m_normals[idx3] += normal;
    }

    // Normalize all the vertex normals
    for (coord& normal : m_normals) {
        normal.normalize();
    }

    std::vector<float> normals;
    normals.resize(m_normals.size()*3);
    
    for(uint32_t i = 0; i < m_normals.size(); i++)
    {
        const uint32_t index = i*3;
        normals[index] = m_normals[i].x;
        normals[index + 1] = m_normals[i].y;
        normals[index + 2] = m_normals[i].z;
    }

    return normals;
}


std::shared_ptr<Unstructured::Octree> IR_UnstructuredGrid::generate_octree()
{
    coord min , max;
    
    for(const auto& point : m_coords)
    {
        if (point.x < min.x) min.x = point.x;
        if (point.y < min.y) min.y = point.y;
        if (point.z < min.z) min.z = point.z;

        if (point.x > max.x) max.x = point.x;
        if (point.y > max.y) max.y = point.y;
        if (point.z > max.z) max.z = point.z;
    }
    
    std::cout << "Min: " << min.x << " " << min.y << " " << min.z << std::endl;
    std::cout << "Max: " << max.x << " " << max.y << " " << max.z << std::endl;

    std::shared_ptr<Unstructured::Octree> octree = std::make_shared<Unstructured::Octree>(min, max);

    // for(auto& triangle : m_triangles)
    // {
    //     octree->add_element(&triangle);
    // }

    // for(auto& quad : m_quads)
    // {
    //     octree->add_element(&quad);
    // }

    for(auto& tetrahedron : m_tetrahedrons)
    {
        octree->add_element(&tetrahedron);
    }

    // for(auto& hexahedron : m_hexahedrons)
    // {
    //     octree->add_element(&hexahedron);
    // }

    // for(auto& pyramid : m_pyramids)
    // {
    //     octree->add_element(&pyramid);
    // }

    // for(auto& prism : m_prisms)
    // {
    //     octree->add_element(&prism);
    // }

    return octree;
}